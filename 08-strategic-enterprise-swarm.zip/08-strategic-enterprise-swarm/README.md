# Use Case 08: Strategic Enterprise Swarm (CEO Strategic Intelligence)

A multi-agent swarm for **CEO & Executive Decision Intelligence**. When leadership asks strategic questions about company performance, expansion bets, or retention drivers, the swarm orchestrates parallel specialist pillars: Revenue & Sales, Customer Retention & Churn, and Product Usage Telemetry, feeding into a Scenario Modeling synthesizer to produce an actionable Executive Brief.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    User([CEO / Executive Leadership]) -->|Strategic Inquiry Prompt| Coordinator[strategic_decision_coordinator]
    
    subgraph Parallel Strategic Pillars
        Coordinator -->|ARR, Win Rates, Pipeline| A1[sales_revenue_intelligence_agent]
        Coordinator -->|NRR, GRR, Churn Drivers| A2[customer_churn_analytics_agent]
        Coordinator -->|MAU, WAU, API Velocity| A3[product_usage_telemetry_agent]
        Coordinator -->|Monte Carlo 3-Yr ROI Modeling| A4[strategic_scenario_modeling_agent]
    end

    A1 --> Synthesis[Barrier & Synthesis Node]
    A2 --> Synthesis
    A3 --> Synthesis
    A4 --> Synthesis

    Synthesis -->|CEO Executive Strategic Brief| User
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`strategic_decision_coordinator`](agents/strategic_decision_coordinator.yaml) | `coordination: "parallel"` | Orchestrates cross-pillar analytics, synthesizes financial and product health into CEO Brief | None (Coordinates specialists) |
| [`sales_revenue_intelligence_agent`](agents/sales_revenue_intelligence_agent.yaml) | `react_intrinsic` | **Revenue Pillar**: Analyzes $48.2M ARR (+34.2% YoY), 3.8x pipeline coverage, Financial Services surge (+52%) | `analyze_sales_revenue_growth` |
| [`customer_churn_analytics_agent`](agents/customer_churn_analytics_agent.yaml) | `react_intrinsic` | **Customer Pillar**: Measures 118.4% NRR, 94.2% GRR, 4.8% logo churn, and identifies mid-market ERP gap | `analyze_customer_retention_and_churn` |
| [`product_usage_telemetry_agent`](agents/product_usage_telemetry_agent.yaml) | `react_intrinsic` | **Product Pillar**: Analyzes 84.2k MAU, 69.9% stickiness, and links Agent Swarms to 132% NRR | `analyze_product_adoption_and_usage` |
| [`strategic_scenario_modeling_agent`](agents/strategic_scenario_modeling_agent.yaml) | `react_intrinsic` | **Simulation Pillar**: Models $28M 3-year ARR lift, 5.4x ROI multiple, and 7.2 month payback period | `simulate_strategic_initiatives` |

---

## 🛠 Tool Definitions

All tools are in [`tools/strategic_decision_tools.py`](tools/strategic_decision_tools.py) decorated with `@tool`:
- `analyze_sales_revenue_growth` — Quarterly ARR, net new bookings, pipeline ratio, and win rates.
- `analyze_customer_retention_and_churn` — Net Revenue Retention (NRR), Gross Revenue Retention, and cohort health.
- `analyze_product_adoption_and_usage` — MAU/WAU engagement, API call growth, and feature-retention correlation.
- `simulate_strategic_initiatives` — Quantitative financial upside forecasting, ROI multiple, and payback timeline.

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to `strategic_decision_coordinator`:

> **"Provide a comprehensive executive brief on our business performance heading into H2 2026. Evaluate sales revenue growth and pipeline, analyze customer retention and churn drivers, assess product telemetry and feature stickiness, and simulate the 3-year ROI of expanding our AI Agent Swarm product investments."**

### 3. Expected Executive Brief
- **Company Trajectory:** Ending ARR $48.2M (+34.2% YoY), Net New ARR $4.2M, Financial Services vertical growing +52%.
- **Retention & NRR:** NRR 118.4%, GRR 94.2%, 6 accounts at risk ($540k ARR) due to mid-market ERP integrations.
- **Product Telemetry:** 84.2k MAU, 69.9% stickiness, 128.4M monthly API calls. Accounts using Multi-Agent Swarms boast 132% NRR.
- **Strategic Simulation:** $2.5M R&D investment in Agent Swarms yields $28M 3-year ARR lift (5.4x ROI, 7.2 mo payback).
