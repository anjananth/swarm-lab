#!/usr/bin/env bash
# Import script for Use Case 08: Strategic Enterprise Swarm (CEO Strategic Intelligence)
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 📊 Watson Orchestrate — Use Case 08: Strategic Enterprise Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] Strategic Decision Tools"
orchestrate tools import -k python -f tools/strategic_decision_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/4] sales_revenue_intelligence_agent"
orchestrate agents import -f agents/sales_revenue_intelligence_agent.yaml

echo "  [2/4] customer_churn_analytics_agent"
orchestrate agents import -f agents/customer_churn_analytics_agent.yaml

echo "  [3/4] product_usage_telemetry_agent"
orchestrate agents import -f agents/product_usage_telemetry_agent.yaml

echo "  [4/4] strategic_scenario_modeling_agent"
orchestrate agents import -f agents/strategic_scenario_modeling_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] strategic_decision_coordinator"
orchestrate agents import -f agents/strategic_decision_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Strategic Enterprise Swarm imported successfully!"
echo "Target Coordinator: strategic_decision_coordinator"
echo "=========================================================="
