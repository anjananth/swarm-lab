"""
Use Case 08 — Strategic Enterprise Swarm (CEO Strategic Intelligence) : Agent Definitions
========================================================================================

    strategic_decision_coordinator         coordination="parallel"
      ├── sales_revenue_intelligence_agent react_intrinsic (Sales Pillar)
      ├── customer_churn_analytics_agent   react_intrinsic (Customer Pillar)
      ├── product_usage_telemetry_agent    react_intrinsic (Product Pillar)
      └── strategic_scenario_modeling_agent react_intrinsic (Synthesis & Simulation)
"""

LLM = "groq/openai/gpt-oss-120b"

sales_revenue_intelligence_agent = {
    "name": "sales_revenue_intelligence_agent",
    "display_name": "Sales Revenue Intelligence Agent",
    "description": (
        "Analyzes quarterly Net New ARR, YoY revenue expansion, win rates by customer tier, "
        "pipeline coverage, and average contract values."
    ),
    "instructions": "You are the Sales & Revenue Intelligence Specialist. Call analyze_sales_revenue_growth  \ with fiscal_quarter.

Return a structured summary with: ending_arr_usd, net_new_arr_this_quarter_usd,  \ yoy_arr_growth_percent, pipeline_coverage_ratio, enterprise_win_rate_percent,  \ and top_performing_vertical.

Rules: Use exact values from tools. Do not delegate.  \ Keep response under 180 words.",
    "tools": ["analyze_sales_revenue_growth"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

customer_churn_analytics_agent = {
    "name": "customer_churn_analytics_agent",
    "display_name": "Customer Churn Analytics Agent",
    "description": (
        "Evaluates Net Revenue Retention (NRR), Gross Revenue Retention (GRR), logo churn, "
        "customer health distribution, and accounts at risk."
    ),
    "instructions": "You are the Customer Churn & Retention Analytics Specialist. Call  \ analyze_customer_retention_and_churn with time_window_months.

Return a structured  \ summary with: net_revenue_retention_nrr_percent, gross_revenue_retention_grr_percent,  \ annualized_logo_churn_percent, primary_churn_driver, accounts_at_risk_count, and  \ arr_at_risk_usd.

Rules: Use exact values from tools. Do not delegate. Keep  \ response under 180 words.",
    "tools": ["analyze_customer_retention_and_churn"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

product_usage_telemetry_agent = {
    "name": "product_usage_telemetry_agent",
    "display_name": "Product Usage Telemetry Agent",
    "description": (
        "Measures product stickiness (WAU/MAU), monthly API invocation volume, feature adoption velocity, "
        "and correlation with customer retention."
    ),
    "instructions": "You are the Product Usage Telemetry Specialist. Call analyze_product_adoption_and_usage.
  
Return a structured summary with: monthly_active_users_mau, weekly_active_users_wau,  \ stickiness_wau_to_mau_percent, monthly_api_calls_total, fastest_growing_feature,  \ and feature_correlation_with_retention.

Rules: Use exact values from tools.  \ Do not delegate. Keep response under 180 words.",
    "tools": ["analyze_product_adoption_and_usage"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

strategic_scenario_modeling_agent = {
    "name": "strategic_scenario_modeling_agent",
    "display_name": "Strategic Scenario Modeling Agent",
    "description": (
        "Simulates financial upside, 3-year ARR lift, ROI multiples, and payback horizons for strategic corporate initiatives."
    ),
    "instructions": "You are the Strategic Modeling & Scenario Simulation Specialist.  \ Call simulate_strategic_initiatives with initiative name and investment budget.
  
Return a structured summary with: modeled_initiative, investment_budget_usd, projected_arr_lift_year1_usd,  \ projected_arr_lift_year3_usd, modeled_roi_multiple, payback_period_months, and  \ strategic_recommendation.

Rules: Use exact values from tools. Do not delegate.  \ Keep response under 180 words.",
    "tools": ["simulate_strategic_initiatives"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

strategic_decision_coordinator = {
    "name": "strategic_decision_coordinator",
    "display_name": "Strategic Decision Swarm Coordinator",
    "description": (
        "Coordinates an Executive Decision Swarm for the CEO and C-suite across Sales Revenue Growth, "
        "Customer Churn & Retention, Product Telemetry & Usage, and Strategic Scenario Modeling. "
        "Synthesizes multi-pillar business intelligence into an authoritative CEO Executive Strategic Brief.\n\n"
        "Always present the result using exactly these sections, in this order:\n\n"
        "## Executive Summary & Strategic Verdict\n"
        "Core business health rating, ending ARR ($48.2M), YoY growth (+34.2%), and key strategic takeaway for leadership.\n\n"
        "## Revenue & Sales Performance (Sales Pillar)\n"
        "Net new ARR this quarter, enterprise win rate, pipeline coverage ratio (3.8x), and top-performing market vertical.\n\n"
        "## Customer Health & Retention (Customer Pillar)\n"
        "Net Revenue Retention (118.4%), Gross Revenue Retention (94.2%), logo churn, at-risk revenue accounts, and primary churn drivers.\n\n"
        "## Product Adoption & Telemetry (Product Pillar)\n"
        "Monthly Active Users (MAU 84.2k), stickiness ratio (69.9%), API call growth (+46.8% QoQ), and correlation between Multi-Agent Swarms and high NRR (132%).\n\n"
        "## Scenario Simulation & ROI (Strategic Modeling)\n"
        "Projected ARR impact of doubling down on AI Agent Swarms ($28M lift over 3 years), ROI multiple (5.4x), and payback timeline.\n\n"
        "## Recommended Executive Actions\n"
        "Prioritized resource allocation, product investment shifts, and enterprise sales focus."
    ),
    "instructions": "You are the Strategic Decision Swarm Coordinator. When the CEO or  \ executive team presents a high-level strategic question on business trajectory  \ and expansion, orchestrate specialist pillars in parallel.

PLANNING RULES:
  1. ALWAYS call submit_plan. NEVER call direct_answer.
2. Plan work across specialist  \ agents:
   - t1 â sales_revenue_intelligence_agent : analyze ARR growth and pipeline
  \   - t2 â customer_churn_analytics_agent : analyze NRR, GRR, and churn drivers
  \   - t3 â product_usage_telemetry_agent : analyze WAU/MAU and feature telemetry
  \   - t4 â strategic_scenario_modeling_agent : simulate revenue and ROI scenarios
  3. Set `requires: []` on all tasks so they run concurrently in parallel.
4. Give  \ each task EXACTLY ONE produces key.
5. Keep display_text short (3-4 words).
  
Synthesize all findings into the CEO Executive Strategic Brief."."
    ),
    "tools": [],
    "collaborators": [
        "sales_revenue_intelligence_agent",
        "customer_churn_analytics_agent",
        "product_usage_telemetry_agent",
        "strategic_scenario_modeling_agent",
    ],
    "llm": LLM,
    "style": "react_intrinsic",
    "coordination": "parallel",
}

AGENTS = [
    sales_revenue_intelligence_agent,
    customer_churn_analytics_agent,
    product_usage_telemetry_agent,
    strategic_scenario_modeling_agent,
    strategic_decision_coordinator,
]
