#!/usr/bin/env bash
# Import script for Use Case 09: Security Response Swarm
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 🚨 Watson Orchestrate — Use Case 09: Security Response Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] Security Response Tools"
orchestrate tools import -k python -f tools/security_response_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/6] threat_intelligence_agent"
orchestrate agents import -f agents/threat_intelligence_agent.yaml

echo "  [2/6] identity_iam_agent"
orchestrate agents import -f agents/identity_iam_agent.yaml

echo "  [3/6] endpoint_vulnerability_agent"
orchestrate agents import -f agents/endpoint_vulnerability_agent.yaml

echo "  [4/6] siem_investigation_agent"
orchestrate agents import -f agents/siem_investigation_agent.yaml

echo "  [5/6] active_remediation_agent"
orchestrate agents import -f agents/active_remediation_agent.yaml

echo "  [6/6] regulatory_compliance_agent"
orchestrate agents import -f agents/regulatory_compliance_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] soc_security_triage_coordinator"
orchestrate agents import -f agents/soc_security_triage_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Security Response Swarm imported successfully!"
echo "Target Coordinator: soc_security_triage_coordinator"
echo "=========================================================="
