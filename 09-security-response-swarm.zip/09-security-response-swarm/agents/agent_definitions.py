"""
Use Case 09 — Security Response Swarm : Agent Definitions
==========================================================

    soc_security_triage_coordinator    coordination="parallel"
      ├── threat_intelligence_agent   react_intrinsic
      ├── identity_iam_agent          react_intrinsic
      ├── endpoint_vulnerability_agent react_intrinsic
      ├── siem_investigation_agent    react_intrinsic
      ├── active_remediation_agent    react_intrinsic
      └── regulatory_compliance_agent react_intrinsic
"""

LLM = "groq/openai/gpt-oss-120b"

threat_intelligence_agent = {
    "name": "threat_intelligence_agent",
    "display_name": "Threat Intelligence Agent",
    "description": (
        "Queries IP reputation, malware hash signatures, threat actor attribution, "
        "and maps adversary behaviors to MITRE ATT&CK techniques."
    ),
    "instructions": "You are the Threat Intelligence Specialist. Call analyze_threat_intelligence  \ with source_ip.

Return a structured summary with: source_ip, ip_reputation_score,  \ threat_actor_group, mitre_attack_techniques, and threat_severity.

Rules: Use  \ exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["analyze_threat_intelligence"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

identity_iam_agent = {
    "name": "identity_iam_agent",
    "display_name": "Identity & IAM Agent",
    "description": (
        "Inspects Okta and AWS IAM authentication telemetry for impossible travel, "
        "anomalous geographical access, and credential leakage."
    ),
    "instructions": "You are the Identity & IAM Security Specialist. Call analyze_identity_and_iam  \ with username and source_ip.

Return a structured summary with: account_name,  \ identity_type, anomaly_detected, origin_geo, privilege_level, and compromise_likelihood.
  
Rules: Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["analyze_identity_and_iam"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

endpoint_vulnerability_agent = {
    "name": "endpoint_vulnerability_agent",
    "display_name": "Endpoint Vulnerability Agent",
    "description": (
        "Correlates host EDR agent status (CrowdStrike Falcon), operating system versions, "
        "and unpatched CVE vulnerabilities on target endpoints."
    ),
    "instructions": "You are the Endpoint Vulnerability Specialist. Call correlate_host_vulnerabilities  \ with target_host.

Return a structured summary with: host_name, endpoint_agent,  \ agent_status, vulnerabilities_exploited, and edr_containment_ready.

Rules:  \ Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["correlate_host_vulnerabilities"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

siem_investigation_agent = {
    "name": "siem_investigation_agent",
    "display_name": "SIEM Investigation Agent",
    "description": (
        "Reconstructs end-to-end adversary attack timeline, spawned process trees, "
        "and checks for unauthorized data exfiltration attempts in SIEM logs."
    ),
    "instructions": "You are the SIEM Timeline Investigation Specialist. Call correlate_security_telemetry  \ with alert_id and target_host.

Return a structured summary with: alert_id,  \ attack_timeline, data_exfiltration_occurred, and containment_status.

Rules:  \ Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["correlate_security_telemetry"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

active_remediation_agent = {
    "name": "active_remediation_agent",
    "display_name": "Active Remediation Agent",
    "description": (
        "Executes automated host network isolation, invalidates active IAM sessions, "
        "revokes compromised API keys, and blocks malicious IPs at edge firewalls."
    ),
    "instructions": "You are the Active Containment & Remediation Specialist. Call execute_active_remediation  \ with target_host, compromised_user, and source_ip.

Return a structured summary  \ with: remediation_actions, threat_neutralized, and completed_at.

Rules: Use  \ exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["execute_active_remediation"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

regulatory_compliance_agent = {
    "name": "regulatory_compliance_agent",
    "display_name": "Regulatory Compliance Agent",
    "description": (
        "Evaluates regulatory breach notification thresholds under GDPR Article 33, HIPAA, "
        "and SEC regulations, generating SOC compliance audit trails."
    ),
    "instructions": "You are the Regulatory Breach & Compliance Specialist. Call generate_breach_compliance_report  \ with alert_id and containment_time_seconds.

Return a structured summary with:  \ alert_id, detection_to_containment_seconds, data_breach_status, mandatory_72h_gdpr_notification_required,  \ and sec_form_8k_material_breach_threshold.

Rules: Use exact values from tools.  \ Do not delegate. Keep response under 180 words.",
    "tools": ["generate_breach_compliance_report"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

soc_security_triage_coordinator = {
    "name": "soc_security_triage_coordinator",
    "display_name": "SOC Security Triage Coordinator",
    "description": (
        "Coordinates an advanced Cybersecurity SOC Incident & Threat Response Swarm across Threat Intelligence, "
        "Identity & IAM compromise, Endpoint Vulnerabilities, SIEM Timeline Investigation, Active Remediation, "
        "and Regulatory Compliance reporting. Synthesizes an authoritative SOC Incident Response & Containment Report.\n\n"
        "Always present the result using exactly these sections, in this order:\n\n"
        "## Incident Alert & Threat Profile\n"
        "Alert ID, targeted host, compromised account, threat actor attribution, and MITRE ATT&CK tactics.\n\n"
        "## Identity & Authentication Findings\n"
        "Identity type, anomalous geo origin (Tor Exit Node), impossible travel status, and leaked credentials confirmation.\n\n"
        "## Attack Timeline & SIEM Investigation\n"
        "Chronological timeline of adversary commands, spawned shells, and blocked exfiltration attempts.\n\n"
        "## Active Containment & Remediation Actions\n"
        "- Host Network Isolation status\n"
        "- IAM active session revocation and key deactivation\n"
        "- Edge firewall / WAF IP block\n\n"
        "## Regulatory Compliance & Breach Assessment\n"
        "Data exfiltration determination (None), GDPR 72h notification threshold (Not Triggered), and SEC Material Breach status.\n\n"
        "## Post-Incident Hardening Actions\n"
        "Service account credential rotation, bastion host MFA enforcement, and forensic disk image retention."
    ),
    "instructions": "You are the SOC Security Triage Coordinator. When a critical cybersecurity  \ alert or intrusion detection event fires, orchestrate all security specialist  \ agents in parallel to investigate the compromise and execute instant containment.
  
PLANNING RULES:
1. ALWAYS call submit_plan. NEVER call direct_answer.
2. Plan  \ work across specialist agents:
   - t1 â threat_intelligence_agent : lookup IOCs  \ and attacker reputation
   - t2 â identity_iam_agent : analyze Okta/IAM logs  \ and impossible travel
   - t3 â endpoint_vulnerability_agent : correlate host  \ EDR and unpatched CVEs
   - t4 â siem_investigation_agent : reconstruct attack  \ timeline and check exfiltration
   - t5 â active_remediation_agent : isolate  \ host, revoke IAM keys, block IP
   - t6 â regulatory_compliance_agent : assess  \ GDPR/SEC breach notification thresholds
3. Set `requires: []` on all tasks so  \ they run concurrently in parallel.
4. Give each task EXACTLY ONE produces key.
  5. Keep display_text short (3-4 words).

Synthesize all outputs into the final  \ SOC Incident Response & Containment Report."."
    ),
    "tools": [],
    "collaborators": [
        "threat_intelligence_agent",
        "identity_iam_agent",
        "endpoint_vulnerability_agent",
        "siem_investigation_agent",
        "active_remediation_agent",
        "regulatory_compliance_agent",
    ],
    "llm": LLM,
    "style": "react_intrinsic",
    "coordination": "parallel",
}

AGENTS = [
    threat_intelligence_agent,
    identity_iam_agent,
    endpoint_vulnerability_agent,
    siem_investigation_agent,
    active_remediation_agent,
    regulatory_compliance_agent,
    soc_security_triage_coordinator,
]
