# Use Case 09: Security Response Swarm

A multi-agent swarm for **Enterprise SOC Incident & Threat Response**. When a critical intrusion detection alert fires (e.g. compromised service account credentials executing reverse shells on production EC2 hosts), the swarm coordinates across Threat Intelligence, Identity & IAM compromise analysis, Endpoint Vulnerability correlation, SIEM timeline reconstruction, automated host/token remediation, and regulatory breach compliance reporting.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    Alert([Critical Security Alert: SEC-ALERT-2026-99120]) --> Triage[soc_security_triage_coordinator]
    
    subgraph Detection & Context Wave
        Triage -->|IP Reputation & MITRE Mapping| Threat[threat_intelligence_agent]
        Triage -->|Impossible Travel & Geo Anomaly| Identity[identity_iam_agent]
        Triage -->|EDR Sensor & Unpatched CVEs| Vuln[endpoint_vulnerability_agent]
    end

    Threat --> InvestigationPhase[Investigation & Forensic Phase]
    Identity --> InvestigationPhase
    Vuln --> InvestigationPhase

    subgraph Timeline Reconstruction
        InvestigationPhase -->|Process Tree & Timeline| SIEM[siem_investigation_agent]
    end

    SIEM --> ResponsePhase[Response & Governance Phase]

    subgraph Active Containment & Governance
        ResponsePhase -->|Isolate Host, Revoke Keys, Block IP| Remed[active_remediation_agent]
        ResponsePhase -->|GDPR 72h & SEC Form 8-K Audit| Comp[regulatory_compliance_agent]
    end

    Remed --> Synthesis[Barrier & SOC Synthesis]
    Comp --> Synthesis

    Synthesis -->|SOC Incident Response & Containment Report| Alert
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`soc_security_triage_coordinator`](agents/soc_security_triage_coordinator.yaml) | `coordination: "parallel"` | Orchestrates multi-stage incident response waves, synthesizes comprehensive Containment Report | None (Coordinates specialists) |
| [`threat_intelligence_agent`](agents/threat_intelligence_agent.yaml) | `react_intrinsic` | Analyzes attacking IP `198.51.100.42`, attributes threat group UNC3821, maps MITRE T1078.004 | `analyze_threat_intelligence` |
| [`identity_iam_agent`](agents/identity_iam_agent.yaml) | `react_intrinsic` | Flags anomalous Tor exit node origin, impossible travel for `svc_deployer_prod` service account | `analyze_identity_and_iam` |
| [`endpoint_vulnerability_agent`](agents/endpoint_vulnerability_agent.yaml) | `react_intrinsic` | Identifies CrowdStrike EDR status and local privilege escalation attempt (CVE-2026-24819) | `correlate_host_vulnerabilities` |
| [`siem_investigation_agent`](agents/siem_investigation_agent.yaml) | `react_intrinsic` | Reconstructs 4-step attack timeline, confirms S3 exfiltration attempt was blocked | `correlate_security_telemetry` |
| [`active_remediation_agent`](agents/active_remediation_agent.yaml) | `react_intrinsic` | Executes network host isolation, invalidates active IAM sessions, blocks IP at edge WAF | `execute_active_remediation` |
| [`regulatory_compliance_agent`](agents/regulatory_compliance_agent.yaml) | `react_intrinsic` | Confirms 0 PII data leaked; 128s containment satisfies GDPR Article 33 and SEC Form 8-K | `generate_breach_compliance_report` |

---

## 🛠 Tool Definitions

All tools are in [`tools/security_response_tools.py`](tools/security_response_tools.py) decorated with `@tool`:
- `analyze_threat_intelligence` — Threat actor attribution, IOC scoring, and MITRE tactics.
- `analyze_identity_and_iam` — Anomaly detection, geographic baseline comparison, and IAM session tracking.
- `correlate_host_vulnerabilities` — CrowdStrike sensor telemetry, OS details, and local CVEs.
- `correlate_security_telemetry` — SIEM chronology, process spawning trees, and exfiltration checks.
- `execute_active_remediation` — Automated host network quarantine, session termination, and firewall rules.
- `generate_breach_compliance_report` — Statutory breach notification evaluation (GDPR, HIPAA, SEC).

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to `soc_security_triage_coordinator`:

> **"Triage critical security intrusion alert SEC-ALERT-2026-99120 on host ip-10-0-4-192.ec2.internal. Attacking IP is 198.51.100.42 targeting service account svc_deployer_prod. Investigate threat actor indicators, IAM session compromise, host vulnerabilities, reconstruct the attack timeline, execute active isolation and credential revocation, and generate the breach compliance report."**

### 3. Expected SOC Incident Report
- **Threat Actor:** Attributed to UNC3821 via Tor Exit Node (AS49102), MITRE T1078.004 / T1059.004.
- **Identity & Host:** `svc_deployer_prod` compromised from foreign IP; privilege escalation via CVE-2026-24819 attempted.
- **Timeline & Containment:** Shell spawned at 13:41 UTC; exfiltration blocked; host network isolated & IAM sessions killed at 13:43 UTC (128-second containment).
- **Compliance Verdict:** No PII exfiltration; GDPR 72h notification and SEC Form 8-K disclosure thresholds NOT triggered.
