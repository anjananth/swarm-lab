#!/usr/bin/env bash
# Import script for Use Case 04: Enterprise Customer Onboarding & KYC Compliance Swarm
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 💳 Watson Orchestrate — Use Case 04: Customer Onboarding Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/4] Identity Verification Tools"
orchestrate tools import -k python -f tools/identity_verification_tools.py

echo "  [2/4] Financial Risk Assessor Tools"
orchestrate tools import -k python -f tools/financial_risk_tools.py

echo "  [3/4] Compliance Audit Tools"
orchestrate tools import -k python -f tools/compliance_audit_tools.py

echo "  [4/4] Account Provisioning Tools"
orchestrate tools import -k python -f tools/account_provisioning_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/4] identity_verification_agent"
orchestrate agents import -f agents/identity_verification_agent.yaml

echo "  [2/4] financial_risk_assessor"
orchestrate agents import -f agents/financial_risk_assessor.yaml

echo "  [3/4] compliance_audit_agent"
orchestrate agents import -f agents/compliance_audit_agent.yaml

echo "  [4/4] account_provisioning_agent"
orchestrate agents import -f agents/account_provisioning_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] customer_onboarding_coordinator"
orchestrate agents import -f agents/customer_onboarding_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Customer Onboarding & KYC Swarm imported successfully!"
echo "Target Coordinator: customer_onboarding_coordinator"
echo "=========================================================="
