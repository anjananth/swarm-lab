"""
Tools for the Financial Risk Assessor agent in Customer Onboarding & KYC Swarm.
"""

import json
from ibm_watsonx_orchestrate.agent_builder.tools import tool

APPLICANT_ID = "APP-KYC-9481"


@tool
def check_credit_profile(
    applicant_id: str = APPLICANT_ID,
    tax_identifier_last4: str = "4182",
) -> str:
    """
    Retrieve credit bureau report (Equifax/Experian/TransUnion), FICO score,
    and open trade lines summary.

    :param applicant_id: Applicant ID
    :param tax_identifier_last4: Last 4 digits of SSN/Tax ID
    :return: JSON with credit score, delinquency history, and revolving balance
    """
    return json.dumps({
        "applicant_id": applicant_id or APPLICANT_ID,
        "credit_bureau": "Experian",
        "fico_score": 782,
        "score_tier": "EXCELLENT",
        "revolving_credit_utilization_percent": 14.2,
        "open_accounts": 8,
        "bankruptcies": 0,
        "derogatory_marks": 0,
        "payment_history_on_time_percent": 100.0,
        "oldest_credit_line_years": 12.4,
        "inquiries_last_6_months": 1,
        "retrieved_at": "2026-07-10T14:22:10Z",
    }, indent=2)


@tool
def analyze_banking_history(
    applicant_id: str = APPLICANT_ID,
    monthly_stated_income_usd: float = 12500.0,
) -> str:
    """
    Analyze linked open banking cash flows (Plaid/Yodlee), verified salary deposits,
    and calculate debt-to-income (DTI) ratio.

    :param applicant_id: Applicant ID
    :param monthly_stated_income_usd: Self-reported monthly gross income
    :return: JSON with verified income, monthly debt obligations, and DTI ratio
    """
    return json.dumps({
        "applicant_id": applicant_id or APPLICANT_ID,
        "data_provider": "Plaid Financial Data Network",
        "verified_monthly_net_income_usd": 9850.00,
        "average_monthly_payroll_deposits_usd": 12500.00,
        "employer_name": "CloudScale Systems Inc.",
        "employment_tenure_months": 38,
        "monthly_recurring_debt_usd": 2100.00,
        "debt_to_income_ratio_percent": 16.8,
        "dti_threshold_max_percent": 43.0,
        "average_checking_balance_usd": 24150.00,
        "overdrafts_last_12_months": 0,
        "cash_flow_stability_score": "HIGH",
    }, indent=2)


@tool
def calculate_risk_tier(
    fico_score: int = 782,
    dti_ratio_percent: float = 16.8,
    stated_monthly_income_usd: float = 12500.0,
) -> str:
    """
    Compute underwriting risk rating, credit limit recommendation, and account tier.

    :param fico_score: FICO credit score (300-850)
    :param dti_ratio_percent: Debt-to-income ratio (0-100)
    :param stated_monthly_income_usd: Monthly gross income
    :return: JSON with overall financial risk tier and recommended credit facilities
    """
    # Use explicit None-safe checks; 0 is an unlikely but valid score
    score = fico_score if fico_score is not None else 782
    dti = dti_ratio_percent if dti_ratio_percent is not None else 16.8

    # Tier classification:
    #   TIER_1_PRIME    — score >= 740 AND dti <= 25%  (top-tier, low leverage)
    #   TIER_2_STANDARD — score >= 670 OR (score >= 740 but dti > 25%)
    #   TIER_3_SUBPRIME — score < 670
    if score >= 740 and dti <= 25.0:
        tier = "TIER_1_PRIME"
        recommended_credit_limit = 25000.00
        deposit_risk = "MINIMAL"
        pricing_tier = "PRIME_PREMIUM_01"
    elif score >= 670:
        tier = "TIER_2_STANDARD"
        recommended_credit_limit = 10000.00
        deposit_risk = "MODERATE"
        pricing_tier = "STANDARD_01"
    else:
        tier = "TIER_3_SUBPRIME"
        recommended_credit_limit = 2000.00
        deposit_risk = "ELEVATED"
        pricing_tier = "SUBPRIME_01"

    return json.dumps({
        "financial_risk_tier": tier,
        "underwriting_verdict": "APPROVED" if tier != "TIER_3_SUBPRIME" else "MANUAL_REVIEW_REQUIRED",
        "recommended_credit_limit_usd": recommended_credit_limit,
        "recommended_daily_withdrawal_limit_usd": 5000.00,
        "deposit_risk_category": deposit_risk,
        "interest_rate_pricing_tier": pricing_tier,
        "requires_collateral": tier == "TIER_3_SUBPRIME",
    }, indent=2)
