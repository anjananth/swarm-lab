"""
Tools for the Account Provisioning Agent in Customer Onboarding & KYC Swarm.
"""

import json
from ibm_watsonx_orchestrate.agent_builder.tools import tool

APPLICANT_ID = "APP-KYC-9481"
APPLICANT_NAME = "Elena Rostova"


@tool
def provision_core_account(
    applicant_id: str = APPLICANT_ID,
    account_tier: str = "TIER_1_PRIME",
    initial_deposit_usd: float = 1000.0,
) -> str:
    """
    Create core banking accounts (DDA Checking + High-Yield Savings) on the ledger.

    :param applicant_id: Applicant ID
    :param account_tier: Tier assigned by underwriting (e.g. TIER_1_PRIME)
    :param initial_deposit_usd: Initial funding amount
    :return: JSON with account numbers, routing number, and ledger creation status
    """
    return json.dumps({
        "applicant_id": applicant_id or APPLICANT_ID,
        "applicant_name": APPLICANT_NAME,
        "core_banking_customer_id": "CUST-883921",
        "checking_account_number": "100293847182",
        "savings_account_number": "200293847183",
        "routing_number": "021000021",
        "account_tier": account_tier or "TIER_1_PRIME",
        "account_status": "ACTIVE",
        "ledger_created_at": "2026-07-10T14:22:30Z",
        "initial_deposit_status": "PENDING_ACH_CLEARING",
        "initial_deposit_amount_usd": initial_deposit_usd or 1000.0,
    }, indent=2)


@tool
def issue_virtual_card(
    customer_id: str = "CUST-883921",
    cardholder_name: str = APPLICANT_NAME,
    credit_limit_usd: float = 25000.0,
) -> str:
    """
    Issue an instant virtual debit/credit card and push digital wallet tokens (Apple/Google Pay).

    :param customer_id: Core customer ID
    :param cardholder_name: Name printed on card
    :param credit_limit_usd: Approved credit line limit
    :return: JSON with card token, last 4 digits, expiry, and Apple Wallet readiness
    """
    return json.dumps({
        "customer_id": customer_id or "CUST-883921",
        "cardholder_name": cardholder_name or APPLICANT_NAME,
        "card_token_id": "CARD-VIRT-9938210",
        "card_brand": "Visa Infinite",
        "card_last4": "4819",
        "expiry_month_year": "08/30",
        "card_status": "ACTIVE",
        "credit_limit_assigned_usd": credit_limit_usd or 25000.0,
        "digital_wallet_provisioning_ready": True,
        "apple_pay_token_status": "READY_FOR_PUSH",
        "google_pay_token_status": "READY_FOR_PUSH",
    }, indent=2)


@tool
def send_welcome_notification(
    customer_id: str = "CUST-883921",
    customer_email: str = "elena.rostova@example.com",
    account_number_last4: str = "7182",
) -> str:
    """
    Dispatch welcome onboarding email and SMS notification containing login activation credentials.

    :param customer_id: Customer ID
    :param customer_email: Customer email address
    :param account_number_last4: Last 4 digits of account number
    :return: JSON confirming email and SMS delivery
    """
    return json.dumps({
        "customer_id": customer_id or "CUST-883921",
        "email_delivery": {
            "recipient": customer_email or "elena.rostova@example.com",
            "subject": "Welcome to Acme Premier Banking — Your Account is Ready",
            "status": "SENT",
            "template_id": "TPL-ONBOARD-WELCOME-PRIME",
        },
        "sms_delivery": {
            "phone_last4": "8821",
            "status": "DELIVERED",
            "message_preview": "Acme Bank: Your Premier Checking account ending in 7182 is now active.",
        },
        "dispatched_at": "2026-07-10T14:22:45Z",
    }, indent=2)
