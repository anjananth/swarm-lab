"""
Tools for the Identity Verification Agent in Customer Onboarding & KYC Swarm.
"""

import json
from ibm_watsonx_orchestrate.agent_builder.tools import tool

# Single source of truth for mock KYC applicant
APPLICANT_ID = "APP-KYC-9481"
APPLICANT_NAME = "Elena Rostova"
DOCUMENT_ID = "PASSPORT-US-991827"


@tool
def verify_identity_document(
    applicant_id: str = APPLICANT_ID,
    document_type: str = "passport",
    document_number: str = "991827364",
) -> str:
    """
    Verify government-issued identity document authenticity, expiration, MRZ checksum,
    and anti-tampering visual security marks.

    :param applicant_id: Applicant identifier (e.g. APP-KYC-9481)
    :param document_type: Document type (passport, national_id, drivers_license)
    :param document_number: Document serial number
    :return: JSON with verification status, expiration check, and tamper analysis
    """
    return json.dumps({
        "applicant_id": applicant_id or APPLICANT_ID,
        "applicant_name": APPLICANT_NAME,
        "document_type": document_type or "passport",
        "document_id": DOCUMENT_ID,
        "issuer_country": "USA",
        "mrz_checksum_valid": True,
        "expiration_date": "2032-08-14",
        "document_status": "VALID",
        "tampering_detected": False,
        "hologram_security_check": "PASS",
        "synthetic_identity_risk_score": 0.04,
        "synthetic_identity_verdict": "LOW_RISK",
        "confidence_score": 0.99,
        "verified_at": "2026-07-10T14:22:00Z",
    }, indent=2)


@tool
def verify_biometric_match(
    applicant_id: str = APPLICANT_ID,
    liveness_probe_id: str = "LIV-88219",
) -> str:
    """
    Compare selfie/liveness video biometric probe against the photo extracted from the ID document.

    :param applicant_id: Applicant ID
    :param liveness_probe_id: Video liveness check probe identifier
    :return: JSON with biometric facial similarity score and spoof detection verdict
    """
    facial_similarity_score = 0.982
    similarity_threshold = 0.850
    return json.dumps({
        "applicant_id": applicant_id or APPLICANT_ID,
        "probe_id": liveness_probe_id or "LIV-88219",
        "facial_similarity_score": facial_similarity_score,
        "similarity_threshold": similarity_threshold,
        # Computed from actual scores — not hardcoded
        "match_verdict": "CONFIRMED_MATCH" if facial_similarity_score >= similarity_threshold else "NO_MATCH",
        "liveness_detection": {
            "passed": True,
            "passive_liveness_score": 0.994,
            "deepfake_probability": 0.002,
            "3d_mesh_depth_verified": True,
        },
        "verified_at": "2026-07-10T14:22:15Z",
    }, indent=2)


@tool
def screen_pep_and_sanctions(
    applicant_name: str = APPLICANT_NAME,
    date_of_birth: str = "1988-04-12",
    country: str = "USA",
) -> str:
    """
    Screen applicant name against Politically Exposed Persons (PEP), OFAC, UN,
    and global law enforcement sanctions watchlists.

    :param applicant_name: Full legal name
    :param date_of_birth: Date of birth (YYYY-MM-DD)
    :param country: Country of citizenship / residence
    :return: JSON with PEP status, sanctions hits, and adverse media flags
    """
    return json.dumps({
        "applicant_name": applicant_name or APPLICANT_NAME,
        "dob": date_of_birth or "1988-04-12",
        "jurisdiction": country or "USA",
        "pep_status": "NOT_PEP",
        "pep_tier": None,
        "ofac_sdn_hit": False,
        "un_sanctions_hit": False,
        "eu_sanctions_hit": False,
        "interpol_red_notice": False,
        "adverse_media_articles_found": 0,
        "overall_screening_verdict": "CLEAR",
        "screened_at": "2026-07-10T14:22:20Z",
    }, indent=2)
