# Use Case 04: Enterprise Customer Onboarding & KYC Compliance Swarm

A multi-agent swarm for **FinTech & Enterprise Banking Customer Onboarding**. When a new customer applies for an account, the swarm coordinates identity/biometric verification, credit and cashflow underwriting risk assessment, regulatory AML/FATCA compliance checks, and core account/virtual card provisioning in parallel.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    User([Applicant / Banking Portal]) -->|Onboarding Request (Elena Rostova)| Coordinator[customer_onboarding_coordinator]
    
    subgraph Parallel Onboarding Wave
        Coordinator -->|Gov ID, Liveness, Watchlist| A1[identity_verification_agent]
        Coordinator -->|FICO, DTI, Banking Cashflow| A2[financial_risk_assessor]
        Coordinator -->|AML Risk, FATCA, Disclosures| A3[compliance_audit_agent]
        Coordinator -->|Core Ledger, Virtual Card, SMS| A4[account_provisioning_agent]
    end

    A1 -->|ID Verified, Biometrics Pass| Synthesis[Barrier & Synthesis Node]
    A2 -->|FICO 782, Tier 1 Prime, $25k Limit| Synthesis
    A3 -->|AML Low Risk, W-9 Match, Disclosures Clear| Synthesis
    A4 -->|Account #, Routing #, Virtual Card Issued| Synthesis

    Synthesis -->|Consolidated Onboarding Decision Report| User
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`customer_onboarding_coordinator`](agents/customer_onboarding_coordinator.yaml) | `coordination: "parallel"` | Orchestrates onboarding workflows, evaluates specialist outputs, produces final Decision Report | None (Coordinates specialists) |
| [`identity_verification_agent`](agents/identity_verification_agent.yaml) | `react_intrinsic` | Validates passport MRZ checksums, biometric selfie liveness, synthetic ID risk, PEP/sanctions | `verify_identity_document`, `verify_biometric_match`, `screen_pep_and_sanctions` |
| [`financial_risk_assessor`](agents/financial_risk_assessor.yaml) | `react_intrinsic` | Experian FICO pull, Plaid open banking cashflows, DTI ratio, assigns Tier 1 Prime credit limit | `check_credit_profile`, `analyze_banking_history`, `calculate_risk_tier` |
| [`compliance_audit_agent`](agents/compliance_audit_agent.yaml) | `react_intrinsic` | Audits AML transaction patterns, FATCA/CRS tax forms (W-9), regulatory consumer disclosures | `check_aml_compliance`, `validate_tax_residency_fatca`, `audit_jurisdictional_rules` |
| [`account_provisioning_agent`](agents/account_provisioning_agent.yaml) | `react_intrinsic` | Provisions DDA checking/savings on core ledger, issues Visa Infinite virtual card, sends welcome SMS/email | `provision_core_account`, `issue_virtual_card`, `send_welcome_notification` |

---

## 🛠 Tool Definitions

All tools are in [`tools/`](tools/) decorated with `@tool` from `ibm_watsonx_orchestrate.agent_builder.tools`:
- [`identity_verification_tools.py`](tools/identity_verification_tools.py) — Government document tamper analysis, passive liveness probe, OFAC/PEP watchlist screening.
- [`financial_risk_tools.py`](tools/financial_risk_tools.py) — Experian FICO report, Plaid income verification, underwriting credit limit tiering.
- [`compliance_audit_tools.py`](tools/compliance_audit_tools.py) — AML scoring, IRS TIN/W-9 validation, CFPB/NYDFS regulatory disclosures.
- [`account_provisioning_tools.py`](tools/account_provisioning_tools.py) — Core ledger account provisioning, instant virtual card issuance, welcome email/SMS dispatch.

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to the `customer_onboarding_coordinator` agent:

> **"Process onboarding application APP-KYC-9481 for Elena Rostova. Execute government ID and biometric verification, assess credit and banking cash flow risk, perform regulatory AML and FATCA compliance checks, and provision core accounts with instant virtual card."**

### 3. Expected Decision Report
- **Decision:** `APPROVED` (Tier 1 Prime, $25,000 Credit Facility).
- **Identity:** Passport valid, 98.2% facial similarity, passive liveness pass (0.994), OFAC/PEP clear.
- **Financial Risk:** FICO 782, DTI 16.8%, verified monthly net income $9,850, deposit risk minimal.
- **Compliance:** AML risk score 12/100, W-9 IRS match confirmed, Reg E/DD disclosures delivered.
- **Provisioning:** Customer `CUST-883921`, Checking ending in `7182`, Visa Infinite ending in `4819` active with Apple Pay push readiness.
