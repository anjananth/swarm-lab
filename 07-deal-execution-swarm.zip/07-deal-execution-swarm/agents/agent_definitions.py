"""
Use Case 07 — Deal Execution Swarm : Agent Definitions
======================================================

    deal_orchestrator_coordinator     coordination="parallel"
      ├── crm_opportunity_agent       react_intrinsic
      ├── legal_contract_agent        react_intrinsic
      ├── pricing_deal_desk_agent     react_intrinsic
      ├── product_feasibility_agent   react_intrinsic
      ├── security_compliance_agent   react_intrinsic
      └── deal_approval_agent         react_intrinsic
"""

LLM = "groq/openai/gpt-oss-120b"

crm_opportunity_agent = {
    "name": "crm_opportunity_agent",
    "display_name": "CRM Opportunity Agent",
    "description": (
        "Pulls enterprise sales opportunity parameters, proposed ARR and TCV, "
        "buyer decision makers, target close dates, and competitive landscape from CRM."
    ),
    "instructions": "You are the CRM Opportunity Specialist. Call lookup_deal_opportunity  \ with opportunity_id.

Return a structured summary with: opportunity_id, account_name,  \ deal_stage, contract_term_years, proposed_arr_usd, proposed_tcv_usd, primary_buyer,  \ and win_probability_percent.

Rules: Use exact values from tools. Do not delegate.  \ Keep response under 180 words.",
    "tools": ["lookup_deal_opportunity"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

legal_contract_agent = {
    "name": "legal_contract_agent",
    "display_name": "Legal Contract Agent",
    "description": (
        "Analyzes Master Services Agreement (MSA) redlines, liability caps, "
        "governing jurisdictions, and custom IP data ownership terms."
    ),
    "instructions": "You are the Legal Contract Specialist. Call review_contract_terms  \ with opportunity_id.

Return a structured summary with: legal_review_status,  \ standard_msa_used, redlines_analyzed, and overall_legal_risk.

Rules: Use exact  \ values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["review_contract_terms"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

pricing_deal_desk_agent = {
    "name": "pricing_deal_desk_agent",
    "display_name": "Pricing & Deal Desk Agent",
    "description": (
        "Evaluates pricing models, multi-year discounting rules, gross margins, "
        "and Deal Desk executive approval delegation matrices."
    ),
    "instructions": "You are the Pricing & Deal Desk Specialist. Call evaluate_pricing_and_discount  \ with proposed_arr_usd and discount_percentage.

Return a structured summary  \ with: list_price_arr_usd, discounted_arr_usd, discount_percent, gross_margin_percent,  \ margin_floor_met, and approval_tier_required.

Rules: Use exact values from  \ tools. Do not delegate. Keep response under 180 words.",
    "tools": ["evaluate_pricing_and_discount"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

product_feasibility_agent = {
    "name": "product_feasibility_agent",
    "display_name": "Product Feasibility Agent",
    "description": (
        "Evaluates technical and roadmap feasibility of custom connectors, "
        "non-standard SLAs, and dedicated cloud infrastructure add-ons."
    ),
    "instructions": "You are the Product & Engineering Feasibility Specialist. Call validate_product_requirements  \ with opportunity_id and requested features.

Return a structured summary with:  \ features_evaluated, roadmap status, target releases, engineering costs, and product_management_signoff.
  
Rules: Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["validate_product_requirements"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

security_compliance_agent = {
    "name": "security_compliance_agent",
    "display_name": "Security & Compliance Agent",
    "description": (
        "Vets customer vendor security questionnaires against SOC 2 Type II, "
        "ISO 27001, data residency, and pen-test certification packages."
    ),
    "instructions": "You are the Security & Compliance Specialist. Call assess_vendor_security_compliance  \ with customer_name.

Return a structured summary with: soc2_type2_certified,  \ iso_27001_certified, gdpr_and_ccpa_compliant, data_residency_guarantee, and ciso_approval_status.
  
Rules: Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["assess_vendor_security_compliance"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

deal_approval_agent = {
    "name": "deal_approval_agent",
    "display_name": "Deal Approval Agent",
    "description": (
        "Routes approved deal terms through Salesforce CPQ, checks VP Sales and Deal Desk sign-offs, "
        "and generates execution-ready contract documents."
    ),
    "instructions": "You are the Deal Approval & Routing Specialist. Call submit_deal_for_approval  \ with opportunity_id, tcv_usd, discount_percent, and strategy summary.

Return  \ a structured summary with: cpq_quote_id, approval_workflow_status, approvers_signed_off,  \ generated_contract_url, and ready_for_docusign.

Rules: Use exact values from  \ tools. Do not delegate. Keep response under 180 words.",
    "tools": ["submit_deal_for_approval"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

deal_orchestrator_coordinator = {
    "name": "deal_orchestrator_coordinator",
    "display_name": "Deal Orchestrator Coordinator",
    "description": (
        "Coordinates an enterprise Deal Execution Swarm across CRM opportunity metrics, legal MSA terms, "
        "pricing and gross margins, product feature roadmap commitments, vendor security vetting, and executive approval routing. "
        "Synthesizes a structured Executive Deal Strategy & Approval Brief.\n\n"
        "Always present the result using exactly these sections, in this order:\n\n"
        "## Opportunity & Financial Overview\n"
        "Account name, opportunity ID, proposed ARR ($750k), 3-year TCV ($2.25M), win probability, and primary buyer.\n\n"
        "## Pricing & Margin Governance\n"
        "List price vs discounted ARR, discount percentage (22%), projected gross margin (77.9%), and Deal Desk threshold compliance.\n\n"
        "## Legal & Contract Terms\n"
        "MSA status, Limitation of Liability clause verdict (2x fees), governing law, and IP data ownership terms.\n\n"
        "## Product & Technical Commitments\n"
        "Custom SAP connector roadmap alignment (Q3 GA), dedicated VPC infrastructure, and engineering cost impact ($0).\n\n"
        "## Security & Compliance Clearance\n"
        "SOC 2 Type II, ISO 27001, data residency, and questionnaire clearance.\n\n"
        "## Deal Strategy & Executive Approval Verdict\n"
        "Overall recommendation (PROCEED TO SIGN / CONDITIONAL / BLOCKED), CPQ quote ID, approvers signed off, and DocuSign readiness."
    ),
    "instructions": "You are the Deal Orchestrator Coordinator. When a high-value enterprise  \ opportunity enters deal execution and negotiation, orchestrate all cross-functional  \ specialist agents in parallel to evaluate terms and build the deal strategy.
  
PLANNING RULES:
1. ALWAYS call submit_plan. NEVER call direct_answer.
2. Plan  \ work across specialist agents:
   - t1 â crm_opportunity_agent : retrieve deal  \ size, stakeholders, and stage
   - t2 â legal_contract_agent : review MSA liability  \ and custom redlines
   - t3 â pricing_deal_desk_agent : calculate margins and  \ discount approvals
   - t4 â product_feasibility_agent : check feature roadmap  \ commitments
   - t5 â security_compliance_agent : verify SOC2 and security questionnaire
  \   - t6 â deal_approval_agent : route quote for executive sign-off
3. Set `requires:  \ []` on all tasks so they run concurrently in parallel.
4. Give each task EXACTLY  \ ONE produces key.
5. Keep display_text short (3-4 words).

Synthesize all  \ specialist outputs into the final Executive Deal Strategy & Approval Brief."."
    ),
    "tools": [],
    "collaborators": [
        "crm_opportunity_agent",
        "legal_contract_agent",
        "pricing_deal_desk_agent",
        "product_feasibility_agent",
        "security_compliance_agent",
        "deal_approval_agent",
    ],
    "llm": LLM,
    "style": "react_intrinsic",
    "coordination": "parallel",
}

AGENTS = [
    crm_opportunity_agent,
    legal_contract_agent,
    pricing_deal_desk_agent,
    product_feasibility_agent,
    security_compliance_agent,
    deal_approval_agent,
    deal_orchestrator_coordinator,
]
