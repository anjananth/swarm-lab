"""
Tools for Deal Execution Swarm
==============================
Covers:
- CRM Opportunity Intelligence
- Legal MSA Redline & Risk Review
- Pricing, Margin & Discount Governance
- Product Roadmap & Feature Commitments
- Security, SOC2 & Compliance Vetting
- Executive Approval Routing
"""

import json
from ibm_watsonx_orchestrate.agent_builder.tools import tool

OPPORTUNITY_ID = "OPP-2026-GLOBAL-771"
ACCOUNT_NAME = "Global Logistics Network"


@tool
def lookup_deal_opportunity(opportunity_id: str = OPPORTUNITY_ID) -> str:
    """
    Retrieve opportunity stage, total contract value (TCV), annual recurring revenue (ARR),
    buyer stakeholder personas, and competitor landscape from CRM.

    :param opportunity_id: Opportunity ID in CRM (e.g. OPP-2026-GLOBAL-771)
    :return: JSON with deal financial parameters, stage, and customer stakeholders
    """
    return json.dumps({
        "opportunity_id": opportunity_id or OPPORTUNITY_ID,
        "account_name": ACCOUNT_NAME,
        "deal_stage": "STAGE_4_NEGOTIATION",
        "contract_term_years": 3,
        "proposed_arr_usd": 750000.00,
        "proposed_tcv_usd": 2250000.00,
        "primary_buyer": "Chief Digital Officer (CDO)",
        "procurement_lead": "Elena Rostova (Head of Procurement)",
        "target_close_date": "2026-07-31",
        "incumbent_competitor": "LegacyCloud Systems",
        "win_probability_percent": 82.0,
    }, indent=2)


@tool
def review_contract_terms(
    opportunity_id: str = OPPORTUNITY_ID,
    indemnity_cap_multiplier: float = 2.0,
    governing_law_state: str = "New York",
) -> str:
    """
    Analyze Master Services Agreement (MSA) redlines, liability caps, and custom IP clauses.

    :param opportunity_id: Opportunity ID
    :param indemnity_cap_multiplier: Requested liability cap multiplier of annual fees
    :param governing_law_state: Governing jurisdiction
    :return: JSON with legal risk score, redline deviation summary, and required legal approvals
    """
    return json.dumps({
        "opportunity_id": opportunity_id or OPPORTUNITY_ID,
        "legal_review_status": "APPROVED_WITH_CONDITIONS",
        "standard_msa_used": True,
        "redlines_analyzed": [
            {
                "clause": "Limitation of Liability",
                "customer_request": f"{indemnity_cap_multiplier}x 12-month fees",
                "standard_policy": "1x 12-month fees",
                "legal_risk": "MEDIUM",
                "verdict": "ACCEPTABLE for deals > $500k ARR with VP Legal sign-off",
            },
            {
                "clause": "Governing Law",
                "customer_request": f"State of {governing_law_state or 'New York'}",
                "standard_policy": "State of New York / Delaware",
                "legal_risk": "LOW",
                "verdict": "STANDARD_MATCH",
            },
            {
                "clause": "Data Ownership",
                "customer_request": "Customer retains 100% IP of prompts and training data",
                "standard_policy": "Customer owns all enterprise data",
                "legal_risk": "LOW",
                "verdict": "COMPLIANT_WITH_ENTERPRISE_POLICY",
            },
        ],
        "overall_legal_risk": "LOW_TO_MEDIUM",
    }, indent=2)


@tool
def evaluate_pricing_and_discount(
    proposed_arr_usd: float = 750000.00,
    discount_percentage: float = 22.0,
    contract_years: int = 3,
) -> str:
    """
    Calculate gross margins, multi-year discounting thresholds, and check deal desk delegation matrix.

    :param proposed_arr_usd: Proposed Annual Recurring Revenue
    :param discount_percentage: Requested discount off list price
    :param contract_years: Multi-year commitment duration
    :return: JSON with margin analysis, ARR yield, and required approval tier
    """
    discount = discount_percentage or 22.0
    arr = proposed_arr_usd or 750000.00
    list_price_arr = arr / (1 - (discount / 100.0))
    gross_margin = 84.5 - (discount * 0.3)

    return json.dumps({
        "list_price_arr_usd": round(list_price_arr, 2),
        "discounted_arr_usd": arr,
        "discount_percent": discount,
        "contract_term_years": contract_years or 3,
        "total_contract_value_usd": arr * (contract_years or 3),
        "gross_margin_percent": round(gross_margin, 1),
        "margin_floor_met": gross_margin >= 70.0,
        "multi_year_prepayment_rebate": "2% annual prepayment applied",
        "deal_desk_policy": "Discounts between 20-25% on 3-year commitments require VP Sales approval.",
        "approval_tier_required": "VP_SALES_AND_DEAL_DESK",
    }, indent=2)


@tool
def validate_product_requirements(
    opportunity_id: str = OPPORTUNITY_ID,
    requested_custom_features: str = "custom_sap_connector,dedicated_vpc",
) -> str:
    """
    Evaluate technical and product feasibility of any requested non-standard SLAs or custom connectors.

    :param opportunity_id: Opportunity ID
    :param requested_custom_features: Comma-separated list of requested capabilities
    :return: JSON with roadmap availability, engineering cost, and release target
    """
    return json.dumps({
        "opportunity_id": opportunity_id or OPPORTUNITY_ID,
        "features_evaluated": [
            {
                "feature": "custom_sap_connector",
                "status": "GA_IN_ROADMAP",
                "target_release": "Q3 2026 (v4.3)",
                "delivery_risk": "LOW — already in active sprint",
                "custom_engineering_cost_usd": 0,
            },
            {
                "feature": "dedicated_vpc",
                "status": "STANDARD_ENTERPRISE_ADDON",
                "target_release": "AVAILABLE_NOW",
                "delivery_risk": "NONE",
                "infrastructure_charge_included": True,
            },
        ],
        "product_management_signoff": "APPROVED_NO_BLOCKERS",
    }, indent=2)


@tool
def assess_vendor_security_compliance(customer_name: str = ACCOUNT_NAME) -> str:
    """
    Verify customer security questionnaire answers against current SOC 2 Type II,
    ISO 27001, and HIPAA / GDPR certification packages.

    :param customer_name: Enterprise customer name
    :return: JSON with compliance certificates, data residency options, and pen test status
    """
    return json.dumps({
        "customer_name": customer_name or ACCOUNT_NAME,
        "soc2_type2_certified": True,
        "iso_27001_certified": True,
        "gdpr_and_ccpa_compliant": True,
        "hipaa_baa_supported": True,
        "data_residency_guarantee": "US-East & EU-Frankfurt isolated tenants available",
        "third_party_pen_test_report_shared": True,
        "security_questionnaire_status": "100%_PASS_CLEARED",
        "ciso_approval_status": "APPROVED",
    }, indent=2)


@tool
def submit_deal_for_approval(
    opportunity_id: str = OPPORTUNITY_ID,
    tcv_usd: float = 2250000.00,
    discount_percent: float = 22.0,
    deal_strategy_summary: str = "3-Year Enterprise commitment with 22% discount and standard Q3 SAP connector delivery.",
) -> str:
    """
    Route finalized deal package to Deal Desk and Executive Approvers in Salesforce CPQ.

    :param opportunity_id: Opportunity ID
    :param tcv_usd: Total contract value
    :param discount_percent: Discount applied
    :param deal_strategy_summary: Deal desk justification
    :return: JSON confirming approval routing, approval status, and CPQ quote generation
    """
    return json.dumps({
        "cpq_quote_id": "QUOTE-2026-881920",
        "opportunity_id": opportunity_id or OPPORTUNITY_ID,
        "tcv_usd": tcv_usd or 2250000.00,
        "discount_applied_percent": discount_percent or 22.0,
        "approval_workflow_status": "APPROVED_AUTOMATICALLY",
        "approvers_signed_off": [
            {"role": "VP Sales", "name": "Marcus Vance", "status": "APPROVED"},
            {"role": "Deal Desk Director", "name": "Amina Patel", "status": "APPROVED"},
            {"role": "VP Legal", "name": "David Sterling", "status": "APPROVED"},
        ],
        "generated_contract_url": "https://contracts.internal/quotes/QUOTE-2026-881920.pdf",
        "ready_for_docusign": True,
    }, indent=2)
