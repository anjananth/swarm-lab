#!/usr/bin/env bash
# Import script for Use Case 07: Deal Execution Swarm
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 💼 Watson Orchestrate — Use Case 07: Deal Execution Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] Deal Execution Tools"
orchestrate tools import -k python -f tools/deal_execution_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/6] crm_opportunity_agent"
orchestrate agents import -f agents/crm_opportunity_agent.yaml

echo "  [2/6] legal_contract_agent"
orchestrate agents import -f agents/legal_contract_agent.yaml

echo "  [3/6] pricing_deal_desk_agent"
orchestrate agents import -f agents/pricing_deal_desk_agent.yaml

echo "  [4/6] product_feasibility_agent"
orchestrate agents import -f agents/product_feasibility_agent.yaml

echo "  [5/6] security_compliance_agent"
orchestrate agents import -f agents/security_compliance_agent.yaml

echo "  [6/6] deal_approval_agent"
orchestrate agents import -f agents/deal_approval_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] deal_orchestrator_coordinator"
orchestrate agents import -f agents/deal_orchestrator_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Deal Execution Swarm imported successfully!"
echo "Target Coordinator: deal_orchestrator_coordinator"
echo "=========================================================="
