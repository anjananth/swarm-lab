# Use Case 07: Deal Execution Swarm

A multi-agent swarm for **Enterprise B2B Deal Execution & Governance**. When a multi-million-dollar sales opportunity enters final contracting and negotiation, the swarm runs parallel evaluations across CRM pipeline metrics, legal redlines (MSA), Deal Desk pricing and gross margins, product feature roadmap commitments, vendor security questionnaires, and automated executive approval routing.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    Opportunity([Sales Opportunity: Global Logistics]) --> Orchestrator[deal_orchestrator_coordinator]
    
    subgraph Parallel Deal Review Wave
        Orchestrator -->|Deal Size & Stakeholders| A1[crm_opportunity_agent]
        Orchestrator -->|MSA & Liability Cap Redlines| A2[legal_contract_agent]
        Orchestrator -->|22% Discount & Margins| A3[pricing_deal_desk_agent]
        Orchestrator -->|SAP Connector Feasibility| A4[product_feasibility_agent]
        Orchestrator -->|SOC 2 Type II & Security Form| A5[security_compliance_agent]
        Orchestrator -->|Executive Routing & CPQ| A6[deal_approval_agent]
    end

    A1 --> Synthesis[Barrier & Deal Strategy Synthesis]
    A2 --> Synthesis
    A3 --> Synthesis
    A4 --> Synthesis
    A5 --> Synthesis
    A6 --> Synthesis

    Synthesis -->|Executive Deal Brief & Sign-off| Opportunity
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`deal_orchestrator_coordinator`](agents/deal_orchestrator_coordinator.yaml) | `coordination: "parallel"` | Orchestrates deal governance, balances commercial discount vs margins, outputs Deal Strategy Brief | None (Coordinates specialists) |
| [`crm_opportunity_agent`](agents/crm_opportunity_agent.yaml) | `react_intrinsic` | Retrieves $750k ARR ($2.25M TCV), Stage 4 Negotiation, CDO buyer, 82% win rate | `lookup_deal_opportunity` |
| [`legal_contract_agent`](agents/legal_contract_agent.yaml) | `react_intrinsic` | Evaluates Limitation of Liability clause (2x annual fees), governing NY law, customer IP terms | `review_contract_terms` |
| [`pricing_deal_desk_agent`](agents/pricing_deal_desk_agent.yaml) | `react_intrinsic` | Models 22% multi-year discount against 77.9% gross margin (well above 70% margin floor) | `evaluate_pricing_and_discount` |
| [`product_feasibility_agent`](agents/product_feasibility_agent.yaml) | `react_intrinsic` | Confirms requested SAP connector is already in Q3 v4.3 GA roadmap with $0 custom cost | `validate_product_requirements` |
| [`security_compliance_agent`](agents/security_compliance_agent.yaml) | `react_intrinsic` | Clears vendor security questionnaire with SOC 2 Type II, ISO 27001, and US/EU data residency | `assess_vendor_security_compliance` |
| [`deal_approval_agent`](agents/deal_approval_agent.yaml) | `react_intrinsic` | Generates CPQ Quote `QUOTE-2026-881920`, gathers VP Sales and Deal Desk sign-offs for DocuSign | `submit_deal_for_approval` |

---

## 🛠 Tool Definitions

All tools are in [`tools/deal_execution_tools.py`](tools/deal_execution_tools.py) decorated with `@tool`:
- `lookup_deal_opportunity` — CRM financials, buyers, and competition.
- `review_contract_terms` — Legal redlines and liability cap assessment.
- `evaluate_pricing_and_discount` — Discounting, margin calculations, and approval tier validation.
- `validate_product_requirements` — Product roadmap and connector availability check.
- `assess_vendor_security_compliance` — SOC2 and ISO compliance certification vetting.
- `submit_deal_for_approval` — CPQ quote generation and executive sign-off routing.

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to `deal_orchestrator_coordinator`:

> **"Evaluate enterprise opportunity OPP-2026-GLOBAL-771 for Global Logistics Network ($750k ARR / 3-Year TCV $2.25M). Review the 22% discount against gross margins, inspect the 2x liability cap MSA redline, confirm Q3 SAP connector roadmap feasibility, verify SOC2 compliance, and route CPQ quote for approval."**

### 3. Expected Executive Deal Brief
- **Deal Summary:** $750,000 ARR, $2,250,000 TCV (3-Year term), 82% win probability.
- **Pricing & Margins:** 22% discount approved at 77.9% gross margin (exceeds 70% threshold).
- **Legal & Risk:** 2x liability cap approved with VP Legal condition; standard NY jurisdiction.
- **Product & Security:** SAP connector confirmed in Q3 GA release with $0 custom dev; SOC 2 Type II cleared.
- **Approval Verdict:** Approved automatically; CPQ Quote `QUOTE-2026-881920` ready for DocuSign execution.
