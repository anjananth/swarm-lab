# Use Case 02: GitHub Pull Request Review Swarm

A multi-agent swarm demonstrating **pure parallel execution** (`coordination: "parallel"`). Three specialist agents perform deep review of a GitHub pull request concurrently across code quality, application security, and documentation completeness with zero dependencies.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    User([Developer / Tech Lead]) -->|Review PR #482 Prompt| Coordinator[pr_review_coordinator]
    
    subgraph Parallel Review Wave (Wave 1)
        Coordinator -->|Static Analysis & Complexity| A1[code_quality_agent]
        Coordinator -->|SAST, CVEs, Secrets| A2[security_agent]
        Coordinator -->|OpenAPI, Docstrings, Changelog| A3[documentation_agent]
    end

    A1 -->|Complexity & Coverage Findings| Synthesis[Barrier & Synthesis Node]
    A2 -->|CWE-89 SQLi & CVE-2024-28849| Synthesis
    A3 -->|Missing OpenAPI & JSDoc Gaps| Synthesis

    Synthesis -->|Consolidated PR Review Report with Verdict| User
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`pr_review_coordinator`](agents/pr_review_coordinator.yaml) | `coordination: "parallel"` | Coordinates review wave, enforces strict report structure, determines overall merge verdict | None (Coordinates specialists) |
| [`code_quality_agent`](agents/code_quality_agent.yaml) | `react_intrinsic` | Cyclomatic/cognitive complexity, code duplication, test coverage against 80% gate | `get_pr_metadata`, `get_pr_diff`, `run_static_analysis` |
| [`security_agent`](agents/security_agent.yaml) | `react_intrinsic` | SAST injection flaws, vulnerable npm dependencies, exposed credentials/secrets | `scan_code_vulnerabilities`, `scan_dependencies`, `check_secret_exposure` |
| [`documentation_agent`](agents/documentation_agent.yaml) | `react_intrinsic` | OpenAPI schema coverage, JSDoc coverage, CHANGELOG and migration notes | `check_api_docs_coverage`, `check_changelog_and_readme` |

---

## 🛠 Tool Definitions

All 8 tools are implemented in [`tools/pr_review_tools.py`](tools/pr_review_tools.py) decorated with `@tool`:
- `get_pr_metadata` — Pull request title, author, branch names, CI checks.
- `get_pr_diff` — Unified diff hunks across changed files.
- `run_static_analysis` — ESLint, SonarQube cognitive complexity, line duplication, unit test coverage.
- `scan_code_vulnerabilities` — Semgrep SAST scanner findings (detects CWE-89 SQL injection and missing ownership checks).
- `scan_dependencies` — npm audit dependency check (detects axios CVE-2024-28849).
- `check_secret_exposure` — Gitleaks credential scanner (verifies false-positive allowlist).
- `check_api_docs_coverage` — OpenAPI endpoint comparison and JSDoc percentage.
- `check_changelog_and_readme` — CHANGELOG.md unreleased section and migration notes.

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to the `pr_review_coordinator` agent:

> **"Review pull request #482 in the acme/payments-api repository. I need the code quality assessment, the security review, and the documentation check before I approve it."**

### 3. Expected Verdict & Findings
- **Verdict:** `REQUEST CHANGES` (Merge blocked due to High Security Vulnerability).
- **Code Quality:** Cognitive complexity 18 in `processRefund()`, 22-line duplication, unawaited promise, 61% coverage vs 80% gate.
- **Security:** **HIGH** CWE-89 SQL injection in `src/db/refund_repository.js:41`, **MEDIUM** CWE-285 missing merchant authorization check, **MEDIUM** axios CVE-2024-28849.
- **Documentation:** Missing OpenAPI spec for `POST /refunds` and `GET /refunds/{refundId}`, 28.6% JSDoc coverage, missing CHANGELOG entry.
