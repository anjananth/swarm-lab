#!/usr/bin/env bash
# Import script for Use Case 02: GitHub Pull Request Review Swarm
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 🔍 Watson Orchestrate — Use Case 02: PR Review Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] PR Review Tools (pr_review_tools.py)"
orchestrate tools import -k python -f tools/pr_review_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/3] code_quality_agent"
orchestrate agents import -f agents/code_quality_agent.yaml

echo "  [2/3] security_agent"
orchestrate agents import -f agents/security_agent.yaml

echo "  [3/3] documentation_agent"
orchestrate agents import -f agents/documentation_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] pr_review_coordinator"
orchestrate agents import -f agents/pr_review_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ PR Review Swarm imported successfully!"
echo "Target Coordinator: pr_review_coordinator"
echo "=========================================================="
