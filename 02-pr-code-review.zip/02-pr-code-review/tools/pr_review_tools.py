"""
Use Case 02 — GitHub Pull Request Review Swarm : Tool Definitions
==================================================================

Demonstrates pure parallel multi-agent review execution.
Three specialists review the pull request concurrently:
1. code_quality_agent
2. security_agent
3. documentation_agent
"""

import json
from ibm_watsonx_orchestrate.agent_builder.tools import tool

# ═════════════════════════════════════════════════════════════════════════════
# Frozen fixture — single source of truth for PR tools
# ═════════════════════════════════════════════════════════════════════════════

REPO = "acme/payments-api"
PR_NUMBER = "482"
PR_TITLE = "Add refund endpoint"
PR_AUTHOR = "dana-kowalski"
BASE_BRANCH = "main"
HEAD_BRANCH = "feature/refund-endpoint"
OPENED_AT = "2027-02-18T09:14:00Z"
HEAD_SHA = "7f3c9a2"

CHANGED_FILES = [
    {"path": "src/api/refunds.js", "status": "added", "additions": 186, "deletions": 0},
    {"path": "src/db/refund_repository.js", "status": "added", "additions": 94, "deletions": 0},
    {"path": "src/api/payments.js", "status": "modified", "additions": 41, "deletions": 29},
    {"path": "src/middleware/validate.js", "status": "modified", "additions": 22, "deletions": 8},
    {"path": "test/refunds.test.js", "status": "added", "additions": 63, "deletions": 0},
    {"path": "package.json", "status": "modified", "additions": 6, "deletions": 0},
]


def _normalize_pr(pr_number: str) -> str:
    """Echo back whatever the caller supplied, defaulting to the fixture PR."""
    value = str(pr_number).strip().lstrip("#")
    return value if value else PR_NUMBER


# ═════════════════════════════════════════════════════════════════════════════
# 1. Code Quality Agent tools
# ═════════════════════════════════════════════════════════════════════════════

@tool
def get_pr_metadata(pr_number: str = "482", repository: str = REPO) -> str:
    """
    Retrieve pull request metadata: title, author, branches, review state, CI
    status, and the list of changed files with line counts.

    :param pr_number: Pull request number to review
    :param repository: Repository in owner/name form
    :return: JSON with PR metadata and the changed file list
    """
    return json.dumps({
        "repository": repository or REPO,
        "pr_number": _normalize_pr(pr_number),
        "title": PR_TITLE,
        "author": PR_AUTHOR,
        "base_branch": BASE_BRANCH,
        "head_branch": HEAD_BRANCH,
        "head_sha": HEAD_SHA,
        "opened_at": OPENED_AT,
        "state": "open",
        "review_state": "awaiting_review",
        "mergeable": True,
        "ci_status": "passing",
        "ci_checks": [
            {"name": "unit-tests", "status": "success", "duration_s": 84},
            {"name": "lint", "status": "success", "duration_s": 19},
            {"name": "build", "status": "success", "duration_s": 132},
        ],
        "files_changed": len(CHANGED_FILES),
        "additions": 412,
        "deletions": 37,
        "files": CHANGED_FILES,
        "labels": ["feature", "payments", "needs-review"],
        "linked_issue": "PAY-1183",
    }, indent=2)


@tool
def get_pr_diff(pr_number: str = "482", file_path: str = "") -> str:
    """
    Retrieve the unified diff hunks for the pull request. Pass a file_path to
    narrow the diff to one file, or leave it empty to get every changed file.

    :param pr_number: Pull request number
    :param file_path: Optional path to restrict the diff to a single file
    :return: JSON with the diff hunks for each changed file
    """
    hunks = [
        {
            "file": "src/api/refunds.js",
            "hunk_header": "@@ -0,0 +1,186 @@",
            "excerpt": (
                "+async function processRefund(req, res) {\n"
                "+  const { paymentId, amount, reason, currency, partial } = req.body;\n"
                "+  if (!paymentId) { return res.status(400).json({ error: 'paymentId required' }); }\n"
                "+  if (!amount) { return res.status(400).json({ error: 'amount required' }); }\n"
                "+  if (amount <= 0) { return res.status(400).json({ error: 'amount must be positive' }); }\n"
                "+  const payment = await repo.findPaymentById(paymentId);\n"
                "+  if (payment.status === 'refunded') { ... }\n"
                "+  else if (payment.status === 'partially_refunded') { ... }\n"
                "+  else if (payment.status === 'disputed') { ... }\n"
                "+  else if (payment.status === 'settled') { ... }\n"
                "+  else if (payment.status === 'pending') { ... }\n"
                "+  gateway.submitRefund(payment, amount);   // return value not awaited or checked\n"
                "+  return res.status(200).json({ ok: true });\n"
                "+}"
            ),
            "notes": "New refund handler. 186 lines, single function body.",
        },
        {
            "file": "src/db/refund_repository.js",
            "hunk_header": "@@ -0,0 +1,94 @@",
            "excerpt": (
                "+async function findRefundsByPayment(paymentId, status) {\n"
                "+  const sql = \"SELECT * FROM refunds WHERE payment_id = '\" + paymentId +\n"
                "+              \"' AND status = '\" + status + \"'\";\n"
                "+  return db.query(sql);\n"
                "+}"
            ),
            "notes": "Query built by string concatenation from request-supplied values.",
        },
        {
            "file": "src/api/payments.js",
            "hunk_header": "@@ -114,29 +114,41 @@",
            "excerpt": (
                "-  if (!body.paymentId) return res.status(400).json({ error: 'paymentId required' });\n"
                "-  if (!body.amount) return res.status(400).json({ error: 'amount required' });\n"
                "+  if (!body.paymentId) { return res.status(400).json({ error: 'paymentId required' }); }\n"
                "+  if (!body.amount) { return res.status(400).json({ error: 'amount required' }); }\n"
                "+  if (body.amount <= 0) { return res.status(400).json({ error: 'amount must be positive' }); }"
            ),
            "notes": "The same validation block now exists in refunds.js and payments.js.",
        },
        {
            "file": "src/middleware/validate.js",
            "hunk_header": "@@ -8,8 +8,22 @@",
            "excerpt": "+  // TODO: wire the shared validator into the refund route before GA",
            "notes": "Shared validator exists but the new route does not use it.",
        },
        {
            "file": "test/refunds.test.js",
            "hunk_header": "@@ -0,0 +1,63 @@",
            "excerpt": (
                "+describe('POST /refunds', () => {\n"
                "+  it('refunds a settled payment', ...);\n"
                "+  it('rejects a missing paymentId', ...);\n"
                "+  it('rejects a negative amount', ...);\n"
                "+});"
            ),
            "notes": "Happy path plus two validation cases. No tests for disputed, partially_refunded, or gateway-failure paths.",
        },
        {
            "file": "package.json",
            "hunk_header": "@@ -21,6 +21,12 @@",
            "excerpt": "+    \"axios\": \"1.6.2\",\n+    \"decimal.js\": \"10.4.3\",",
            "notes": "Two new runtime dependencies.",
        },
    ]

    wanted = str(file_path).strip()
    if wanted:
        filtered = [h for h in hunks if h["file"] == wanted]
        if filtered:
            hunks = filtered

    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "head_sha": HEAD_SHA,
        "hunks": hunks,
    }, indent=2)


@tool
def run_static_analysis(pr_number: str = "482") -> str:
    """
    Run the static analysis suite (ESLint, complexity, duplication, coverage)
    against the changed files and return every finding with file and line.

    :param pr_number: Pull request number
    :return: JSON with static analysis findings, complexity, and coverage
    """
    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "analyzer": "eslint@8.57 + sonar-scanner@5.0",
        "findings": [
            {
                "id": "CQ-1",
                "severity": "major",
                "rule": "cognitive-complexity",
                "file": "src/api/refunds.js",
                "line": 34,
                "symbol": "processRefund()",
                "message": "Cognitive complexity is 18 (threshold 10). Six sequential status branches in one function body.",
                "suggestion": "Extract the status handling into a lookup table or per-status handler functions.",
            },
            {
                "id": "CQ-2",
                "severity": "major",
                "rule": "duplicated-block",
                "file": "src/api/refunds.js",
                "line": 12,
                "duplicate_of": "src/api/payments.js:114",
                "message": "22-line request validation block duplicated between refunds.js and payments.js.",
                "suggestion": "Use the shared validator in src/middleware/validate.js — it is already imported but unused.",
            },
            {
                "id": "CQ-3",
                "severity": "major",
                "rule": "no-floating-promises",
                "file": "src/api/refunds.js",
                "line": 151,
                "message": "gateway.submitRefund() returns a promise that is neither awaited nor error-checked. A gateway failure returns HTTP 200 to the caller with no refund recorded.",
                "suggestion": "Await the call and map a rejection to HTTP 502.",
            },
            {
                "id": "CQ-4",
                "severity": "minor",
                "rule": "unused-import",
                "file": "src/middleware/validate.js",
                "line": 3,
                "message": "validateRefundRequest is exported but never imported by the refund route.",
                "suggestion": "Wire it into the route or remove it.",
            },
        ],
        "metrics": {
            "cognitive_complexity_max": 18,
            "complexity_threshold": 10,
            "duplicated_lines": 22,
            "duplication_pct": 5.3,
            "test_coverage_new_code_pct": 61.0,
            "coverage_gate_pct": 80.0,
            "coverage_gate_passed": False,
            "uncovered_paths": [
                "refund of a disputed payment",
                "refund of a partially_refunded payment",
                "gateway submitRefund() rejection",
            ],
        },
        "summary": "4 findings (3 major, 1 minor). Coverage gate FAILED at 61% against an 80% threshold.",
    }, indent=2)


# ═════════════════════════════════════════════════════════════════════════════
# 2. Security Agent tools
# ═════════════════════════════════════════════════════════════════════════════

@tool
def scan_code_vulnerabilities(pr_number: str = "482") -> str:
    """
    Run the SAST scanner over the code introduced by this pull request and
    return each vulnerability with its CWE, severity, and remediation.

    :param pr_number: Pull request number
    :return: JSON with code vulnerability findings
    """
    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "scanner": "semgrep@1.62 (ruleset: javascript.security.audit)",
        "findings": [
            {
                "id": "SEC-1",
                "severity": "HIGH",
                "cwe": "CWE-89",
                "title": "SQL injection via string-concatenated query",
                "file": "src/db/refund_repository.js",
                "line": 41,
                "symbol": "findRefundsByPayment()",
                "evidence": "const sql = \"SELECT * FROM refunds WHERE payment_id = '\" + paymentId + \"' AND status = '\" + status + \"'\";",
                "exploitability": "paymentId and status reach this function directly from the POST /refunds request body with no sanitization.",
                "remediation": "Use a parameterized query: db.query('SELECT * FROM refunds WHERE payment_id = $1 AND status = $2', [paymentId, status]).",
                "blocks_merge": True,
            },
            {
                "id": "SEC-2",
                "severity": "MEDIUM",
                "cwe": "CWE-285",
                "title": "Missing ownership check on refund",
                "file": "src/api/refunds.js",
                "line": 58,
                "evidence": "The handler loads the payment by ID but never verifies that the authenticated caller owns it.",
                "exploitability": "An authenticated merchant could refund another merchant's payment by guessing a payment ID.",
                "remediation": "Assert payment.merchant_id === req.auth.merchant_id before submitting the refund.",
                "blocks_merge": True,
            },
            {
                "id": "SEC-3",
                "severity": "LOW",
                "cwe": "CWE-532",
                "title": "Payment identifier written to application log",
                "file": "src/api/refunds.js",
                "line": 172,
                "evidence": "logger.info(`refund submitted for ${paymentId}`)",
                "remediation": "Log a hashed or truncated identifier.",
                "blocks_merge": False,
            },
        ],
        "summary": "3 code findings: 1 HIGH, 1 MEDIUM, 1 LOW. 2 findings block merge.",
    }, indent=2)


@tool
def scan_dependencies(pr_number: str = "482") -> str:
    """
    Check the dependencies added or changed by this pull request against the
    vulnerability database and the internal license policy.

    :param pr_number: Pull request number
    :return: JSON with dependency vulnerability and license findings
    """
    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "scanner": "npm-audit + snyk-db snapshot 2027-02-18",
        "dependencies_added": [
            {
                "name": "axios",
                "version": "1.6.2",
                "license": "MIT",
                "license_approved": True,
                "vulnerabilities": [
                    {
                        "id": "SEC-4",
                        "cve": "CVE-2024-28849",
                        "severity": "MEDIUM",
                        "cvss": 6.5,
                        "title": "Proxy-Authorization header leaked on cross-host redirect",
                        "affected_range": "<1.6.8",
                        "fixed_version": "1.6.8",
                        "remediation": "Bump axios to 1.6.8 or later.",
                        "blocks_merge": False,
                    }
                ],
            },
            {
                "name": "decimal.js",
                "version": "10.4.3",
                "license": "MIT",
                "license_approved": True,
                "vulnerabilities": [],
            },
        ],
        "transitive_alerts": 0,
        "license_policy": "pass — all added dependencies are MIT",
        "summary": "1 MEDIUM dependency vulnerability (axios CVE-2024-28849), fixed by upgrading to 1.6.8. No license violations.",
    }, indent=2)


@tool
def check_secret_exposure(pr_number: str = "482") -> str:
    """
    Scan the diff for hardcoded credentials, API keys, tokens, and private keys.

    :param pr_number: Pull request number
    :return: JSON with the secret scanning result
    """
    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "scanner": "gitleaks@8.18",
        "files_scanned": len(CHANGED_FILES),
        "confirmed_secrets": [],
        "suppressed_matches": [
            {
                "file": "test/refunds.test.js",
                "line": 11,
                "pattern": "stripe-test-key",
                "value_preview": "sk_test_4eC39H****",
                "verdict": "false positive — documented Stripe sandbox key, already on the allowlist",
            }
        ],
        "result": "PASS",
        "summary": "No live secrets detected. One sandbox test key matched and was confirmed as an allowlisted false positive.",
    }, indent=2)


# ═════════════════════════════════════════════════════════════════════════════
# 3. Documentation Agent tools
# ═════════════════════════════════════════════════════════════════════════════

@tool
def check_api_docs_coverage(pr_number: str = "482") -> str:
    """
    Compare the API routes introduced by this pull request against the committed
    OpenAPI specification and report any undocumented endpoints, parameters, or
    error responses.

    :param pr_number: Pull request number
    :return: JSON with API documentation coverage gaps
    """
    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "spec_file": "docs/openapi.yaml",
        "spec_last_modified_in_pr": False,
        "routes_added": [
            {
                "method": "POST",
                "path": "/refunds",
                "documented": False,
                "gap": "Endpoint is entirely absent from docs/openapi.yaml.",
                "required_fields_undocumented": ["paymentId", "amount", "reason", "currency", "partial"],
                "error_responses_undocumented": ["400", "403", "409", "502"],
            },
            {
                "method": "GET",
                "path": "/refunds/{refundId}",
                "documented": False,
                "gap": "Endpoint is entirely absent from docs/openapi.yaml.",
                "required_fields_undocumented": [],
                "error_responses_undocumented": ["404"],
            },
        ],
        "routes_modified": [
            {
                "method": "POST",
                "path": "/payments",
                "documented": True,
                "gap": "Spec still omits the new 400 response for a non-positive amount.",
            }
        ],
        "docstring_coverage": {
            "new_exported_functions": 7,
            "with_jsdoc": 2,
            "coverage_pct": 28.6,
            "threshold_pct": 70.0,
            "gate_passed": False,
            "missing_jsdoc": [
                "processRefund()",
                "findRefundsByPayment()",
                "buildRefundPayload()",
                "mapGatewayError()",
                "assertRefundable()",
            ],
        },
        "summary": "2 new public endpoints are undocumented, 1 modified endpoint has a stale error list, and JSDoc coverage is 28.6% against a 70% gate.",
    }, indent=2)


@tool
def check_changelog_and_readme(pr_number: str = "482") -> str:
    """
    Verify that the repository's release and onboarding documentation was updated
    alongside the code: CHANGELOG entry, README, migration notes, and ADRs.

    :param pr_number: Pull request number
    :return: JSON with the state of each documentation artifact
    """
    return json.dumps({
        "repository": REPO,
        "pr_number": _normalize_pr(pr_number),
        "artifacts": [
            {
                "artifact": "CHANGELOG.md",
                "updated_in_pr": False,
                "required": True,
                "policy": "Every PR labelled 'feature' must add an Unreleased entry.",
                "gap": "No entry added for the refund endpoint.",
                "suggested_entry": "### Added\n- `POST /refunds` and `GET /refunds/{refundId}` for full and partial payment refunds (PAY-1183).",
            },
            {
                "artifact": "README.md",
                "updated_in_pr": False,
                "required": False,
                "policy": "Update only when setup steps or env vars change.",
                "gap": "None — this PR adds no new environment variables or setup steps.",
                "suggested_entry": "",
            },
            {
                "artifact": "docs/migrations/",
                "updated_in_pr": False,
                "required": True,
                "policy": "Any new table requires a migration note.",
                "gap": "The PR reads and writes a `refunds` table, but no migration note records how that table is created or backfilled.",
                "suggested_entry": "Add docs/migrations/2027-02-refunds-table.md describing the schema and the backfill plan.",
            },
            {
                "artifact": "docs/adr/",
                "updated_in_pr": False,
                "required": False,
                "policy": "Required for architectural decisions only.",
                "gap": "None — this PR follows the existing payments service pattern.",
                "suggested_entry": "",
            },
        ],
        "summary": "2 required documentation artifacts are missing (CHANGELOG entry, migration note). README and ADR are correctly untouched.",
    }, indent=2)
