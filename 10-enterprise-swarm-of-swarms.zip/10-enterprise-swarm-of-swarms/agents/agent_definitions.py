"""
Use Case 10 — Enterprise Swarm of Swarms : Agent Definitions
============================================================

    enterprise_mission_coordinator          coordination="parallel" (Mission Agent)
      ├── business_domain_swarm_agent       react_intrinsic (Sales, HR, Finance)
      ├── it_infrastructure_swarm_agent     react_intrinsic (DevOps, Cloud, Security)
      ├── customer_operations_swarm_agent   react_intrinsic (Support, Success, Retention)
      └── enterprise_strategy_synthesis_agent react_intrinsic (Roadmap & Governance)
"""

LLM = "groq/openai/gpt-oss-120b"

business_domain_swarm_agent = {
    "name": "business_domain_swarm_agent",
    "display_name": "Business Domain Swarm Agent",
    "description": (
        "Coordinates the Business Domain sub-swarm across Sales bookings and pipeline, "
        "HR recruitment pacing, and Finance budget variance."
    ),
    "instructions": "You are the Business Domain Swarm Specialist. Call assess_business_readiness  \ with target_quarter and budget_allocated_usd.

Return a structured summary with:  \ domain, mission_name, sales_pillar, hr_pillar, finance_pillar, and overall_business_readiness.
  
Rules: Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["assess_business_readiness"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

it_infrastructure_swarm_agent = {
    "name": "it_infrastructure_swarm_agent",
    "display_name": "IT Infrastructure Swarm Agent",
    "description": (
        "Coordinates the IT Domain sub-swarm across multi-region cloud capacity, "
        "Kubernetes auto-scaling headroom, DevOps CI/CD pipelines, and SecOps compliance."
    ),
    "instructions": "You are the IT Infrastructure Swarm Specialist. Call assess_it_and_cloud_capacity  \ with projected_concurrent_users and target_cloud_regions.

Return a structured  \ summary with: domain, mission_name, infrastructure_capacity, devops_pipeline,  \ security_governance, and overall_it_readiness.

Rules: Use exact values from  \ tools. Do not delegate. Keep response under 180 words.",
    "tools": ["assess_it_and_cloud_capacity"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

customer_operations_swarm_agent = {
    "name": "customer_operations_swarm_agent",
    "display_name": "Customer Operations Swarm Agent",
    "description": (
        "Coordinates the Customer Operations sub-swarm across 24x7 support staffing, "
        "surge capacity buffers, Customer Success ratios, and training documentation coverage."
    ),
    "instructions": "You are the Customer Operations Swarm Specialist. Call assess_customer_readiness  \ with customer_tier_focus and anticipated_ticket_surge_percent.

Return a structured  \ summary with: domain, mission_name, support_operations, customer_success, knowledge_and_training,  \ and overall_customer_readiness.

Rules: Use exact values from tools. Do not  \ delegate. Keep response under 180 words.",
    "tools": ["assess_customer_readiness"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

enterprise_strategy_synthesis_agent = {
    "name": "enterprise_strategy_synthesis_agent",
    "display_name": "Enterprise Strategy Synthesis Agent",
    "description": (
        "Synthesizes multi-swarm inputs into a unified enterprise launch roadmap, "
        "critical path milestone schedule, risk mitigation matrix, and executive sign-off."
    ),
    "instructions": "You are the Enterprise Strategy & Roadmap Synthesis Specialist. Call  \ synthesize_enterprise_mission_plan with mission_name and launch_date.

Return  \ a structured summary with: mission_name, target_launch_date, enterprise_go_decision,  \ confidence_score, critical_path_milestones, enterprise_risk_matrix, and executive_sponsors_aligned.
  
Rules: Use exact values from tools. Do not delegate. Keep response under 180 words.",
    "tools": ["synthesize_enterprise_mission_plan"],
    "collaborators": [],
    "llm": LLM,
    "style": "react_intrinsic",
}

enterprise_mission_coordinator = {
    "name": "enterprise_mission_coordinator",
    "display_name": "Enterprise Mission Coordinator (Swarm of Swarms)",
    "description": (
        "Coordinates a hierarchical Enterprise Swarm of Swarms across Business (Sales, HR, Finance), "
        "IT Infrastructure (Cloud, DevOps, SecOps), Customer Operations (Support, Success), and Enterprise Roadmap Synthesis. "
        "Decomposes high-level strategic enterprise goals and generates a comprehensive Enterprise Mission Launch & Execution Brief.\n\n"
        "Always present the result using exactly these sections, in this order:\n\n"
        "## Enterprise Mission Overview & Go/No-Go Decision\n"
        "Mission title, target launch date, overall executive verdict (GO FOR LAUNCH / CONDITIONAL / DELAY), and readiness confidence score.\n\n"
        "## Business Domain Readiness (Business Swarm)\n"
        "Sales quota attainment ($12M target), HR recruiting progress (21 of 24 hires), and Finance budget variance ($350k buffer on $5M budget).\n\n"
        "## IT & Cloud Infrastructure Capacity (IT Swarm)\n"
        "Multi-region cloud compute headroom (42%), DevOps CI/CD canary cycle times (8.5m), and SecOps certification clearance.\n\n"
        "## Customer Operations & Enablement (Customer Swarm)\n"
        "24x7 support readiness, 50% surge buffer, CSM coverage ratio (1:12), and customer training documentation coverage (98%).\n\n"
        "## Critical Path Milestones & Cross-Domain Dependencies\n"
        "A chronological timeline of key deliverables across all 3 domain swarms leading up to launch day.\n\n"
        "## Executive Risk Matrix & Mitigation\n"
        "Identified cross-functional risks, severity, mitigation strategy, and executive sponsor sign-offs."
    ),
    "instructions": "You are the Enterprise Mission Coordinator. When the executive leadership  \ assigns a strategic enterprise goal or global product launch mission, orchestrate  \ all major domain swarms in parallel to evaluate organizational readiness.

  PLANNING RULES:
1. ALWAYS call submit_plan. NEVER call direct_answer.
2. Plan  \ work across domain specialist agents:
   - t1 â business_domain_swarm_agent :  \ evaluate Sales pipeline, HR hiring, and Finance budget
   - t2 â it_infrastructure_swarm_agent  \ : assess multi-region cloud scaling, DevOps, and SecOps
   - t3 â customer_operations_swarm_agent  \ : verify 24x7 support staffing, CSM ratios, and documentation
   - t4 â enterprise_strategy_synthesis_agent  \ : build cross-swarm critical path and risk matrix
3. Set `requires: []` on all  \ tasks so they run concurrently in parallel.
4. Give each task EXACTLY ONE produces  \ key.
5. Keep display_text short (3-4 words).

Synthesize all outputs into the  \ final Enterprise Mission Launch & Execution Brief."."
    ),
    "tools": [],
    "collaborators": [
        "business_domain_swarm_agent",
        "it_infrastructure_swarm_agent",
        "customer_operations_swarm_agent",
        "enterprise_strategy_synthesis_agent",
    ],
    "llm": LLM,
    "style": "react_intrinsic",
    "coordination": "parallel",
}

AGENTS = [
    business_domain_swarm_agent,
    it_infrastructure_swarm_agent,
    customer_operations_swarm_agent,
    enterprise_strategy_synthesis_agent,
    enterprise_mission_coordinator,
]
