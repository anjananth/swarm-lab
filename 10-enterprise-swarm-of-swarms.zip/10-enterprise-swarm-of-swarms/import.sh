#!/usr/bin/env bash
# Import script for Use Case 10: Enterprise Swarm of Swarms
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 🌐 Watson Orchestrate — Use Case 10: Enterprise Swarm of Swarms"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] Enterprise Mission Tools"
orchestrate tools import -k python -f tools/enterprise_mission_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Domain Swarm Agents ──"

echo "  [1/4] business_domain_swarm_agent"
orchestrate agents import -f agents/business_domain_swarm_agent.yaml

echo "  [2/4] it_infrastructure_swarm_agent"
orchestrate agents import -f agents/it_infrastructure_swarm_agent.yaml

echo "  [3/4] customer_operations_swarm_agent"
orchestrate agents import -f agents/customer_operations_swarm_agent.yaml

echo "  [4/4] enterprise_strategy_synthesis_agent"
orchestrate agents import -f agents/enterprise_strategy_synthesis_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] enterprise_mission_coordinator"
orchestrate agents import -f agents/enterprise_mission_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Enterprise Swarm of Swarms imported successfully!"
echo "Target Coordinator: enterprise_mission_coordinator"
echo "=========================================================="
