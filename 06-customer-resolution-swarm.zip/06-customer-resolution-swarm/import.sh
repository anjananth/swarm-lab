#!/usr/bin/env bash
# Import script for Use Case 06: Customer Resolution Swarm
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 🎧 Watson Orchestrate — Use Case 06: Customer Resolution Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] Customer Resolution Tools"
orchestrate tools import -k python -f tools/customer_resolution_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/6] crm_context_agent"
orchestrate agents import -f agents/crm_context_agent.yaml

echo "  [2/6] product_entitlement_agent"
orchestrate agents import -f agents/product_entitlement_agent.yaml

echo "  [3/6] knowledge_solution_agent"
orchestrate agents import -f agents/knowledge_solution_agent.yaml

echo "  [4/6] billing_action_agent"
orchestrate agents import -f agents/billing_action_agent.yaml

echo "  [5/6] technical_remediation_agent"
orchestrate agents import -f agents/technical_remediation_agent.yaml

echo "  [6/6] escalation_management_agent"
orchestrate agents import -f agents/escalation_management_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] customer_resolution_triage_coordinator"
orchestrate agents import -f agents/customer_resolution_triage_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Customer Resolution Swarm imported successfully!"
echo "Target Coordinator: customer_resolution_triage_coordinator"
echo "=========================================================="
