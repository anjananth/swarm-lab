# Use Case 06: Customer Resolution Swarm

A multi-agent swarm for **Enterprise Customer Support & Complex Incident Resolution**. When a customer submits an urgent request (e.g., API quota exhaustion or critical error), the swarm runs context discovery and active resolution across CRM, product telemetry, engineering knowledge bases, billing adjustments, and technical rate-limiter resets.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    User([Enterprise Customer / Ticket]) -->|Customer Request (Acme Retail)| Triage[customer_resolution_triage_coordinator]
    
    subgraph Context & Discovery Wave
        Triage -->|Lookup Tier, Health, ARR| CRM[crm_context_agent]
        Triage -->|Inspect Quotas & Flags| Product[product_entitlement_agent]
        Triage -->|Search Resolution SOPs| KB[knowledge_solution_agent]
    end

    CRM --> ResolutionPhase[Resolution & Action Wave]
    Product --> ResolutionPhase
    KB --> ResolutionPhase

    subgraph Resolution & Remediation Wave
        ResolutionPhase -->|Apply Emergency Burst| Billing[billing_action_agent]
        ResolutionPhase -->|Reset Rate Limiter| Tech[technical_remediation_agent]
        ResolutionPhase -->|Update Ticket & Alert CSM| Esc[escalation_management_agent]
    end

    Billing --> Synthesis[Barrier & Synthesis Node]
    Tech --> Synthesis
    Esc --> Synthesis

    Synthesis -->|Customer Resolution Summary & Direct Response| User
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`customer_resolution_triage_coordinator`](agents/customer_resolution_triage_coordinator.yaml) | `coordination: "parallel"` | Orchestrates context discovery & resolution waves, drafts synthesized customer reply | None (Coordinates specialists) |
| [`crm_context_agent`](agents/crm_context_agent.yaml) | `react_intrinsic` | Retrieves Salesforce/HubSpot account tier (Enterprise Platinum), ARR ($480k), and health score | `lookup_customer_crm` |
| [`product_entitlement_agent`](agents/product_entitlement_agent.yaml) | `react_intrinsic` | Checks monthly API quota (5M calls), 97.8% utilization, and throttling triggers | `inspect_product_entitlements` |
| [`knowledge_solution_agent`](agents/knowledge_solution_agent.yaml) | `react_intrinsic` | Pulls knowledge base articles on emergency quota bursts and rate limiting | `query_knowledge_base` |
| [`billing_action_agent`](agents/billing_action_agent.yaml) | `react_intrinsic` | Allocates 1M emergency burst calls, waives $1,500 overage fee in Zuora/Stripe | `apply_billing_adjustment` |
| [`technical_remediation_agent`](agents/technical_remediation_agent.yaml) | `react_intrinsic` | Flushes gateway token buckets, clears 429 errors, verifies p95 latency | `execute_technical_remediation` |
| [`escalation_management_agent`](agents/escalation_management_agent.yaml) | `react_intrinsic` | Updates ticket to RESOLVED, alerts assigned CSM (Sarah Jenkins), posts Slack update | `update_and_escalate_ticket` |

---

## 🛠 Tool Definitions

All tools are in [`tools/customer_resolution_tools.py`](tools/customer_resolution_tools.py) decorated with `@tool`:
- `lookup_customer_crm` — Pulls customer tier, ARR ($480k), health score (68), and CSM details.
- `inspect_product_entitlements` — Analyzes license usage, API call quota, and active feature flags.
- `query_knowledge_base` — Searches SOPs for enterprise burst allocation and rate limit policies.
- `apply_billing_adjustment` — Grants emergency quota burst and updates billing ledger.
- `execute_technical_remediation` — Flushes gateway rate limiters across all 8 nodes.
- `update_and_escalate_ticket` — Sets ticket status to RESOLVED and alerts CSM and Slack.

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to `customer_resolution_triage_coordinator`:

> **"Customer Acme Retail Corp (CUST-ENTERPRISE-8821) is reporting 429 Too Many Requests errors and API throttling blocking their checkout traffic. Investigate customer tier and quota entitlements, apply necessary billing adjustments, execute rate-limiter remediation, and update support ticket TICK-2026-99381."**

### 3. Expected Resolution Report
- **Customer Context:** Enterprise Platinum ($480,000 ARR), CSM Sarah Jenkins, SLA 24x7 Mission Critical.
- **Root Cause:** 97.8% quota utilization (4.89M of 5M calls) triggered automated gateway rate limiting.
- **Actions Taken:** 1,000,000 emergency quota burst applied, $1,500 fee waived, 8 gateway nodes cache-flushed, 429 errors dropped to 0.0%.
- **Ticket Status:** Ticket `TICK-2026-99381` resolved in 11.4 minutes, CSM notified for follow-up quota expansion discussion.
