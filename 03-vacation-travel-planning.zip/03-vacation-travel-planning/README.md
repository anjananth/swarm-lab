# Use Case 03: Family Vacation Planning Swarm (Parallel + Emergent)

A multi-agent swarm demonstrating **Parallel Execution with Emergent Specialist Discovery** (`coordination: "parallel"`). The coordinator dispatches planned tasks in parallel (Flights, Hotel, Activities). When the hotel specialist discovers that the chosen property requires ground transport (`ground_transport_required: true`), it dynamically spawns a follow-on task to `local_transport_agent` via `post_follow_on_task`.

---

## 🏗 Architecture & Collaboration Flow

```mermaid
flowchart TD
    User([Traveller]) -->|Family Trip Prompt| Coordinator[vacation_planning_coordinator]
    
    subgraph Wave 1: Planned Parallel Tasks
        Coordinator -->|Search Flights & Baggage| A1[flight_search_agent]
        Coordinator -->|Search Family Suites| A2[hotel_search_agent]
        Coordinator -->|Activities & Schedules| A3[activities_agent]
    end

    A2 -.->|Discovers ground_transport_required: true<br/>Calls post_follow_on_task| FollowOn[(Emergent Task Queue)]

    A1 --> Barrier1[Barrier Node]
    A2 --> Barrier1
    A3 --> Barrier1

    subgraph Wave 2: Emergent Task
        Barrier1 -->|Spawns Emergent Task| A4[local_transport_agent]
    end

    A4 --> Synthesis[Final Barrier & Synthesis]

    Synthesis -->|Complete Family Itinerary & Budget Report| User
```

---

## 🤖 Agents Roster

| Agent Name | Type | Key Role | Assigned Tools |
|---|---|---|---|
| [`vacation_planning_coordinator`](agents/vacation_planning_coordinator.yaml) | `coordination: "parallel"` | Plans initial 3 tasks, collects wave 1 + emergent results, synthesizes final itinerary & budget | None (Coordinates specialists) |
| [`flight_search_agent`](agents/flight_search_agent.yaml) | `react_intrinsic` | Non-stop flight itineraries, baggage allowance, family adjacent seating fees | `search_flights`, `check_baggage_and_seating` |
| [`hotel_search_agent`](agents/hotel_search_agent.yaml) | `react_intrinsic` | **Delegator Agent**: Family room availability, detects transport isolation, calls `post_follow_on_task` | `search_hotels`, `check_room_availability` |
| [`activities_agent`](agents/activities_agent.yaml) | `react_intrinsic` | Day-by-day kid-friendly activity schedules, age fit, opening hours validation | `find_family_activities`, `check_activity_availability` |
| [`local_transport_agent`](agents/local_transport_agent.yaml) | `react_intrinsic` | **Emergent Specialist**: Private airport van with child seats, Hola Barcelona transit cards, Montserrat day-trip coach | `get_airport_transfer_options`, `get_transit_passes`, `get_day_trip_transport` |

---

## 🛠 Tool Definitions

All 9 tools are implemented in [`tools/vacation_tools.py`](tools/vacation_tools.py) decorated with `@tool`:
- `search_flights` — Searches round-trip flights for family (picks Iberia IB6166 non-stop).
- `check_baggage_and_seating` — Validates family baggage rules and seat reservation fees ($2,180 subtotal).
- `search_hotels` — Finds Hotel Marina Vell with `ground_transport_required: true` ($1,540 subtotal).
- `check_room_availability` — Reconfirms room availability and late arrival policy.
- `find_family_activities` — Recommends 7 kid-friendly attractions ($690 subtotal).
- `check_activity_availability` — Organizes day-by-day slots, shifts Tibidabo closure.
- `get_airport_transfer_options` — Selects late-night private van with 2 child seats ($190).
- `get_transit_passes` — Evaluates Hola Barcelona 4-day all-zone card ($128).
- `get_day_trip_transport` — Selects direct Montserrat family coach ($97). Total transport subtotal: $415.

---

## 🚀 How to Import and Run

### 1. Import into Watson Orchestrate
```bash
bash import.sh
```

### 2. Sample Prompt
Send the following prompt to the `vacation_planning_coordinator` agent:

> **"Plan a 5-day family vacation to Barcelona for 2 adults and 2 children aged 7 and 11. We fly from Boston, departing March 14 2027 and returning March 18. Total budget is $6,000. I need flights, a hotel, and things to do with the kids."**

### 3. Expected Budget Table
The coordinator synthesizes all costs into an exact arithmetic budget:

| Category | Subtotal |
|---|---|
| Flights (Iberia IB6166, non-stop both ways) | $2,180 |
| Hotel (Marina Vell Castelldefels, 4 nights) | $1,540 |
| Activities (7 experiences) | $690 |
| Local Transport *(Emergent)* | $415 |
| **Total** | **$4,825** of $6,000 — **$1,175 remaining** |
