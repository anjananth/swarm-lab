"""
Use Case 03 — Family Vacation Planning Swarm : Tool Definitions
==============================================================

Demonstrates PARALLEL + EMERGENT execution under `coordination="parallel"`.

    WAVE 1 (planned, fully parallel — no dependencies)
        flight_search_agent    requires: []  produces: ["flight_options"]
        hotel_search_agent     requires: []  produces: ["hotel_selection"]
        activities_agent       requires: []  produces: ["activity_plan"]

    WAVE 2 (EMERGENT — never appears in the coordinator's initial plan)
        local_transport_agent  requires: ["hotel_selection"] produces: ["local_transport_plan"]
"""

import json
from ibm_watsonx_orchestrate.agent_builder.tools import tool

# ═════════════════════════════════════════════════════════════════════════════
# Frozen scenario constants — single source of truth for all nine tools
# ═════════════════════════════════════════════════════════════════════════════

ORIGIN_CITY = "Boston"
ORIGIN_AIRPORT = "BOS"
DEST_CITY = "Barcelona"
DEST_AIRPORT = "BCN"
DEPART_DATE = "2027-03-14"
RETURN_DATE = "2027-03-18"
NIGHTS = 4
TRAVELLERS = "2 adults, 2 children (ages 7 and 11)"
BUDGET_USD = 6000

# Category subtotals — fixed so the grand total is always $4,825.
FLIGHTS_SUBTOTAL = 2180
HOTEL_SUBTOTAL = 1540
ACTIVITIES_SUBTOTAL = 690
TRANSPORT_SUBTOTAL = 415

# The recommended hotel. Its distance from the centre is what makes ground
# transport a discovered requirement rather than a planned task.
HOTEL_ID = "BCN-CST-118"
HOTEL_NAME = "Hotel Marina Vell, Castelldefels"
ARRIVAL_TIME_LOCAL = "22:55"


# ═════════════════════════════════════════════════════════════════════════════
# 1. Flight Search Agent tools
# ═════════════════════════════════════════════════════════════════════════════

@tool
def search_flights(
    origin: str = ORIGIN_AIRPORT,
    destination: str = DEST_AIRPORT,
    departure_date: str = DEPART_DATE,
    return_date: str = RETURN_DATE,
    passengers: str = "4",
) -> str:
    """
    Search round-trip flight options for a family, ranked by total price with
    the family's connection and timing constraints applied.

    :param origin: Departure airport or city
    :param destination: Arrival airport or city
    :param departure_date: Outbound date in YYYY-MM-DD form
    :param return_date: Return date in YYYY-MM-DD form
    :param passengers: Total number of travellers
    :return: JSON with ranked flight options and the recommended itinerary
    """
    return json.dumps({
        "search": {
            "origin": origin or ORIGIN_AIRPORT,
            "destination": destination or DEST_AIRPORT,
            "departure_date": departure_date or DEPART_DATE,
            "return_date": return_date or RETURN_DATE,
            "passengers": passengers or "4",
            "cabin": "economy",
        },
        "options": [
            {
                "rank": 1,
                "recommended": True,
                "itinerary_id": "IB6166",
                "carrier": "Iberia",
                "outbound": {
                    "flight": "IB 6166",
                    "depart": "2027-03-14 18:20 EDT (BOS)",
                    "arrive": "2027-03-15 " + ARRIVAL_TIME_LOCAL + " CET (BCN)",
                    "note": "Arrival is 22:55 local time — the family lands late at night.",
                    "duration": "7h 35m",
                    "stops": 0,
                },
                "inbound": {
                    "flight": "IB 6165",
                    "depart": "2027-03-18 11:05 CET (BCN)",
                    "arrive": "2027-03-18 13:45 EDT (BOS)",
                    "duration": "8h 40m",
                    "stops": 0,
                },
                "fare_per_person_usd": 520,
                "fare_total_usd": 2080,
                "why_recommended": "Only non-stop option in budget; children stay on one aircraft in each direction.",
            },
            {
                "rank": 2,
                "recommended": False,
                "itinerary_id": "DL2244",
                "carrier": "Delta / Air France",
                "outbound": {
                    "flight": "DL 2244 + AF 1348",
                    "depart": "2027-03-14 16:40 EDT (BOS)",
                    "arrive": "2027-03-15 12:10 CET (BCN)",
                    "duration": "13h 30m",
                    "stops": 1,
                    "connection": "CDG, 3h 05m layover",
                },
                "inbound": {
                    "flight": "AF 1349 + DL 2245",
                    "depart": "2027-03-18 07:15 CET (BCN)",
                    "arrive": "2027-03-18 16:20 EDT (BOS)",
                    "duration": "14h 05m",
                    "stops": 1,
                },
                "fare_per_person_usd": 468,
                "fare_total_usd": 1872,
                "why_not_recommended": "Cheaper, but a 3-hour connection each way and a 07:15 departure with young children.",
            },
            {
                "rank": 3,
                "recommended": False,
                "itinerary_id": "LH4410",
                "carrier": "Lufthansa",
                "outbound": {
                    "flight": "LH 4410 + LH 1130",
                    "depart": "2027-03-14 21:55 EDT (BOS)",
                    "arrive": "2027-03-15 18:35 CET (BCN)",
                    "duration": "14h 40m",
                    "stops": 1,
                    "connection": "FRA, 4h 20m layover",
                },
                "inbound": {
                    "flight": "LH 1131 + LH 4411",
                    "depart": "2027-03-18 06:00 CET (BCN)",
                    "arrive": "2027-03-18 15:10 EDT (BOS)",
                    "duration": "15h 10m",
                    "stops": 1,
                },
                "fare_per_person_usd": 611,
                "fare_total_usd": 2444,
                "why_not_recommended": "Most expensive and the longest total travel time.",
            },
        ],
        "recommendation": "IB6166 — non-stop both ways at $2,080 for four travellers.",
    }, indent=2)


@tool
def check_baggage_and_seating(itinerary_id: str = "IB6166", passengers: str = "4") -> str:
    """
    Retrieve the baggage allowance, seat availability, and family seating fees
    for a chosen flight itinerary, and return the all-in flight subtotal.

    :param itinerary_id: Itinerary identifier returned by search_flights
    :param passengers: Total number of travellers
    :return: JSON with baggage rules, seating, fees, and the flight category subtotal
    """
    return json.dumps({
        "itinerary_id": itinerary_id or "IB6166",
        "carrier": "Iberia",
        "passengers": passengers or "4",
        "baggage": {
            "carry_on_included": "1 cabin bag + 1 personal item per traveller",
            "checked_included": "1 x 23 kg per traveller",
            "extra_checked_bag_usd": 0,
            "note": "Included allowance is sufficient for a 5-day trip; no extra bags needed.",
        },
        "seating": {
            "family_block_available": True,
            "rows_held": "Row 24 A-B-C and Row 24 D-E-F",
            "adjacent_seating_confirmed": True,
            "seat_selection_fee_usd": 100,
            "fee_note": "$25 per traveller to lock adjacent seats for both legs — recommended so the children sit with an adult.",
        },
        "children": {
            "minor_documentation_required": "Passport per child; no unaccompanied minor forms as both children travel with parents.",
            "child_meal_available": True,
            "child_meal_fee_usd": 0,
        },
        "fare_total_usd": 2080,
        "fees_usd": 100,
        "subtotal_usd": FLIGHTS_SUBTOTAL,
        "subtotal_note": "Flights category subtotal is $2,180 ($2,080 fares + $100 seat selection).",
    }, indent=2)


# ═════════════════════════════════════════════════════════════════════════════
# 2. Hotel Search Agent tools
# ═════════════════════════════════════════════════════════════════════════════

@tool
def search_hotels(
    city: str = DEST_CITY,
    check_in: str = "2027-03-15",
    check_out: str = RETURN_DATE,
    guests: str = "2 adults, 2 children",
) -> str:
    """
    Search family accommodation for the requested city and dates. Each result
    reports whether the property is reachable on public transport or whether
    guests must arrange their own ground transport.

    :param city: Destination city
    :param check_in: Check-in date in YYYY-MM-DD form
    :param check_out: Check-out date in YYYY-MM-DD form
    :param guests: Party composition
    :return: JSON with ranked properties, availability, and ground transport status
    """
    return json.dumps({
        "search": {
            "city": city or DEST_CITY,
            "check_in": check_in or "2027-03-15",
            "check_out": check_out or RETURN_DATE,
            "nights": NIGHTS,
            "guests": guests or "2 adults, 2 children",
            "budget_ceiling_per_night_usd": 420,
        },
        "properties": [
            {
                "rank": 1,
                "recommended": True,
                "hotel_id": HOTEL_ID,
                "name": HOTEL_NAME,
                "rating": 4.5,
                "room_type": "Family Suite — 1 king + 2 singles, sea view",
                "sleeps": 4,
                "availability": "AVAILABLE for all 4 nights",
                "rate_per_night_usd": 385,
                "nights": NIGHTS,
                "subtotal_usd": HOTEL_SUBTOTAL,
                "family_amenities": [
                    "Children's pool and supervised kids' club",
                    "Cots and bed rails available at no charge",
                    "Breakfast included for children under 12",
                    "In-room kitchenette",
                ],
                "location": {
                    "district": "Castelldefels beachfront",
                    "distance_to_city_centre_km": 19,
                    "distance_to_airport_km": 12,
                    "nearest_metro_station": "none within 2.4 km",
                    "airport_shuttle": False,
                    "hotel_parking_usd_per_night": 24,
                },
                "ground_transport_required": True,
                "transport_note": (
                    "This property is 19 km from the city centre with no airport shuttle "
                    "and no metro station within 2.4 km. Guests MUST arrange their own "
                    "ground transport for the airport transfer and for daily travel into "
                    "Barcelona. Ground transport is NOT included in the room rate and is "
                    "NOT arranged by the property."
                ),
                "why_recommended": "The only property with genuine family-suite availability for these dates inside the nightly budget.",
            },
            {
                "rank": 2,
                "recommended": False,
                "hotel_id": "BCN-EIX-402",
                "name": "Eixample Central Family Rooms",
                "rating": 4.4,
                "room_type": "Family Room — 1 king + bunk beds",
                "sleeps": 4,
                "availability": "SOLD OUT — no family rooms for 15–18 March 2027",
                "rate_per_night_usd": 340,
                "location": {
                    "district": "Eixample",
                    "distance_to_city_centre_km": 1.2,
                    "nearest_metro_station": "Girona (180 m)",
                    "airport_shuttle": True,
                },
                "ground_transport_required": False,
                "why_not_recommended": "Cannot be booked — family rooms are sold out for the requested dates.",
            },
            {
                "rank": 3,
                "recommended": False,
                "hotel_id": "BCN-GOT-770",
                "name": "Gothic Quarter Grand Suites",
                "rating": 4.7,
                "room_type": "Two-Bedroom Suite",
                "sleeps": 5,
                "availability": "AVAILABLE for all 4 nights",
                "rate_per_night_usd": 610,
                "nights": NIGHTS,
                "subtotal_usd": 2440,
                "location": {
                    "district": "Gothic Quarter",
                    "distance_to_city_centre_km": 0.4,
                    "nearest_metro_station": "Jaume I (220 m)",
                    "airport_shuttle": True,
                },
                "ground_transport_required": False,
                "why_not_recommended": "At $2,440 for four nights it consumes 41% of the $6,000 total budget and leaves the trip short.",
            },
        ],
        "recommendation": HOTEL_NAME + " — $385/night, $1,540 for four nights.",
    }, indent=2)


@tool
def check_room_availability(
    hotel_id: str = HOTEL_ID,
    check_in: str = "2027-03-15",
    check_out: str = RETURN_DATE,
) -> str:
    """
    Confirm live room availability, the cancellation policy, and any guest
    requirements for a specific property before it is recommended.

    :param hotel_id: Property identifier returned by search_hotels
    :param check_in: Check-in date in YYYY-MM-DD form
    :param check_out: Check-out date in YYYY-MM-DD form
    :return: JSON with the confirmed booking terms and guest requirements
    """
    return json.dumps({
        "hotel_id": hotel_id or HOTEL_ID,
        "name": HOTEL_NAME,
        "check_in": check_in or "2027-03-15",
        "check_out": check_out or RETURN_DATE,
        "nights": NIGHTS,
        "room_type": "Family Suite — 1 king + 2 singles, sea view",
        "rooms_remaining": 2,
        "status": "CONFIRMED_AVAILABLE",
        "rate_per_night_usd": 385,
        "subtotal_usd": HOTEL_SUBTOTAL,
        "taxes_and_fees_included": True,
        "cancellation_policy": "Free cancellation until 2027-03-08, then one night charged.",
        "check_in_time": "15:00",
        "late_arrival_desk": "24-hour reception — late arrivals accepted with no surcharge.",
        "guest_requirements": [
            "Photo ID for both adults at check-in",
            "Children under 12 stay free in the family suite",
        ],
        "ground_transport_required": True,
        "transport_note": (
            "Reconfirmed at booking: no shuttle service operates to this property and the "
            "nearest metro is 2.4 km away. The guest must arrange an airport transfer for "
            "the late-evening arrival and daily transport into central Barcelona."
        ),
    }, indent=2)


# ═════════════════════════════════════════════════════════════════════════════
# 3. Activities Agent tools
# ═════════════════════════════════════════════════════════════════════════════

@tool
def find_family_activities(
    city: str = DEST_CITY,
    children_ages: str = "7, 11",
    trip_days: str = "5",
) -> str:
    """
    Find family-friendly attractions and experiences suitable for the children's
    ages, with per-family pricing and the recommended age fit for each.

    :param city: Destination city
    :param children_ages: Comma-separated ages of the children travelling
    :param trip_days: Number of days available for activities
    :return: JSON with recommended activities, prices, and the activities subtotal
    """
    return json.dumps({
        "search": {
            "city": city or DEST_CITY,
            "children_ages": children_ages or "7, 11",
            "trip_days": trip_days or "5",
            "party": TRAVELLERS,
        },
        "activities": [
            {
                "activity_id": "ACT-PGU",
                "name": "Park Güell — family entry",
                "category": "landmark",
                "duration_hours": 2.5,
                "age_fit": "excellent for both children — open air, short walking loop",
                "family_price_usd": 68,
                "location": "Gràcia, central Barcelona",
                "booking": "timed entry, book ahead",
            },
            {
                "activity_id": "ACT-SAG",
                "name": "Sagrada Família — guided family tour",
                "category": "landmark",
                "duration_hours": 2.0,
                "age_fit": "good — the family tour is paced for children",
                "family_price_usd": 152,
                "location": "Eixample, central Barcelona",
                "booking": "timed entry, book ahead",
            },
            {
                "activity_id": "ACT-COS",
                "name": "CosmoCaixa Science Museum",
                "category": "museum",
                "duration_hours": 3.0,
                "age_fit": "excellent — hands-on floor designed for ages 5-12",
                "family_price_usd": 32,
                "location": "Sarrià, central Barcelona",
                "booking": "walk-in",
            },
            {
                "activity_id": "ACT-AQU",
                "name": "Barcelona Aquarium",
                "category": "attraction",
                "duration_hours": 2.5,
                "age_fit": "excellent for the 7-year-old, good for the 11-year-old",
                "family_price_usd": 96,
                "location": "Port Vell, central Barcelona",
                "booking": "walk-in",
            },
            {
                "activity_id": "ACT-TIB",
                "name": "Tibidabo Amusement Park — family day pass",
                "category": "attraction",
                "duration_hours": 5.0,
                "age_fit": "excellent for both — heritage rides plus modern attractions",
                "family_price_usd": 154,
                "location": "Tibidabo hill, 30 min from the centre",
                "booking": "book ahead",
            },
            {
                "activity_id": "ACT-MON",
                "name": "Montserrat monastery + cable car family pass",
                "category": "day trip",
                "duration_hours": 6.0,
                "age_fit": "good — cable car is the highlight for children",
                "family_price_usd": 88,
                "location": "Montserrat, 48 km outside Barcelona",
                "booking": "book ahead",
                "note": "Day trip outside the city — the family needs transport to reach it.",
            },
            {
                "activity_id": "ACT-PAE",
                "name": "Family paella cooking workshop",
                "category": "experience",
                "duration_hours": 2.5,
                "age_fit": "good — children cook alongside the adults",
                "family_price_usd": 100,
                "location": "El Born, central Barcelona",
                "booking": "book ahead",
            },
        ],
        "activity_count": 7,
        "subtotal_usd": ACTIVITIES_SUBTOTAL,
        "subtotal_note": "Activities category subtotal is $690 for all seven experiences.",
    }, indent=2)


@tool
def check_activity_availability(
    activity_ids: str = "ACT-PGU,ACT-SAG,ACT-COS,ACT-AQU,ACT-TIB,ACT-MON,ACT-PAE",
    trip_start: str = "2027-03-15",
    trip_end: str = RETURN_DATE,
) -> str:
    """
    Confirm bookable time slots for the selected activities across the trip dates
    and return a day-by-day schedule that respects opening days and travel time.

    :param activity_ids: Comma-separated activity identifiers to confirm
    :param trip_start: First full day in the destination, YYYY-MM-DD
    :param trip_end: Departure day, YYYY-MM-DD
    :return: JSON with confirmed slots and a suggested day-by-day schedule
    """
    return json.dumps({
        "requested": activity_ids or "all",
        "trip_start": trip_start or "2027-03-15",
        "trip_end": trip_end or RETURN_DATE,
        "confirmed_slots": [
            {"activity_id": "ACT-PGU", "date": "2027-03-15", "slot": "10:00", "status": "AVAILABLE"},
            {"activity_id": "ACT-SAG", "date": "2027-03-15", "slot": "15:00", "status": "AVAILABLE"},
            {"activity_id": "ACT-COS", "date": "2027-03-16", "slot": "10:30", "status": "AVAILABLE"},
            {"activity_id": "ACT-AQU", "date": "2027-03-16", "slot": "15:30", "status": "AVAILABLE"},
            {"activity_id": "ACT-MON", "date": "2027-03-17", "slot": "09:00", "status": "AVAILABLE"},
            {"activity_id": "ACT-PAE", "date": "2027-03-17", "slot": "18:00", "status": "AVAILABLE"},
            {
                "activity_id": "ACT-TIB",
                "date": "2027-03-18",
                "slot": "closed",
                "status": "UNAVAILABLE — Tibidabo is closed on Thursdays; moved to 2027-03-16",
            },
        ],
        "suggested_schedule": [
            {"day": "Mon 15 Mar", "plan": "Park Güell (10:00), Sagrada Família (15:00)"},
            {"day": "Tue 16 Mar", "plan": "CosmoCaixa (10:30), Barcelona Aquarium (15:30)"},
            {"day": "Wed 17 Mar", "plan": "Montserrat day trip (09:00), paella workshop (18:00)"},
            {"day": "Thu 18 Mar", "plan": "Departure day — morning free, flight at 11:05"},
        ],
        "schedule_note": "Tibidabo is closed on the departure Thursday; held as alternate for Tuesday.",
        "subtotal_usd": ACTIVITIES_SUBTOTAL,
    }, indent=2)


# ═════════════════════════════════════════════════════════════════════════════
# 4. Local Transport Agent tools (EMERGENT specialist — never planned upfront)
# ═════════════════════════════════════════════════════════════════════════════

@tool
def get_airport_transfer_options(
    hotel_id: str = HOTEL_ID,
    arrival_time: str = ARRIVAL_TIME_LOCAL,
    passengers: str = "4",
) -> str:
    """
    Retrieve airport transfer options between the airport and a specific property,
    filtered for party size, luggage, child seat requirements, and arrival time.

    :param hotel_id: Property identifier the transfer must serve
    :param arrival_time: Local arrival time in HH:MM form
    :param passengers: Total number of travellers
    :return: JSON with transfer options and the recommended booking
    """
    return json.dumps({
        "hotel_id": hotel_id or HOTEL_ID,
        "hotel_name": HOTEL_NAME,
        "airport": DEST_AIRPORT,
        "distance_km": 12,
        "arrival_time_local": arrival_time or ARRIVAL_TIME_LOCAL,
        "passengers": passengers or "4",
        "options": [
            {
                "option_id": "TR-VAN",
                "recommended": True,
                "mode": "Pre-booked private van with 2 child seats",
                "capacity": 6,
                "journey_minutes": 20,
                "operates_at_arrival_time": True,
                "price_each_way_usd": 95,
                "round_trip_usd": 190,
                "why_recommended": "The 22:55 arrival falls outside airport bus hours. Pre-booked van meets family with child seats.",
            },
            {
                "option_id": "TR-TAXI",
                "recommended": False,
                "mode": "Airport taxi rank",
                "capacity": 4,
                "journey_minutes": 22,
                "operates_at_arrival_time": True,
                "price_each_way_usd": 78,
                "round_trip_usd": 156,
                "why_not_recommended": "Cheaper, but Barcelona taxis do not guarantee child seats.",
            },
            {
                "option_id": "TR-BUS",
                "recommended": False,
                "mode": "Airport express bus + local connection",
                "capacity": "unlimited",
                "journey_minutes": 75,
                "operates_at_arrival_time": False,
                "price_each_way_usd": 24,
                "round_trip_usd": 48,
                "why_not_recommended": "Last service departs at 22:30 — does not run for a 22:55 arrival.",
            },
        ],
        "recommendation": "TR-VAN — $190 round trip, the only option that works for a 22:55 arrival with two children.",
        "subtotal_usd": 190,
    }, indent=2)


@tool
def get_transit_passes(
    city: str = DEST_CITY,
    travel_days: str = "4",
    travellers: str = "2 adults, 2 children",
) -> str:
    """
    Compare public transport passes for daily travel between the accommodation and
    the city centre, priced for the party composition and number of travel days.

    :param city: Destination city
    :param travel_days: Number of days requiring city travel
    :param travellers: Party composition
    :return: JSON with pass options and the recommended purchase
    """
    return json.dumps({
        "city": city or DEST_CITY,
        "travel_days": travel_days or "4",
        "travellers": travellers or "2 adults, 2 children",
        "context": "The hotel sits in zone 4; central attractions are in zone 1, so passes must cover multi-zone travel.",
        "options": [
            {
                "pass_id": "PASS-HOLA-4",
                "recommended": True,
                "name": "Hola Barcelona Travel Card — 4 days, all zones",
                "covers": "Unlimited metro, tram, and R2 Nord train",
                "adult_price_usd": 44,
                "child_price_usd": 20,
                "adults": 2,
                "children": 2,
                "total_usd": 128,
                "why_recommended": "Covers every centre trip from the hotel for all four days; cheaper than single tickets.",
            },
            {
                "pass_id": "PASS-T10",
                "recommended": False,
                "name": "T-Casual 10-journey ticket, zone 1-4",
                "total_usd": 168,
                "why_not_recommended": "Non-transferable between family members.",
            },
        ],
        "recommendation": "PASS-HOLA-4 — $128 for the family for four days.",
        "subtotal_usd": 128,
    }, indent=2)


@tool
def get_day_trip_transport(
    destination: str = "Montserrat",
    travel_date: str = "2027-03-17",
    passengers: str = "4",
) -> str:
    """
    Retrieve transport options for an out-of-city day trip, including departure
    points, journey time, and family pricing.

    :param destination: Day trip destination outside the city
    :param travel_date: Date of the day trip in YYYY-MM-DD form
    :param passengers: Total number of travellers
    :return: JSON with day trip transport options and the recommended booking
    """
    return json.dumps({
        "destination": destination or "Montserrat",
        "travel_date": travel_date or "2027-03-17",
        "passengers": passengers or "4",
        "distance_km": 48,
        "options": [
            {
                "option_id": "DT-COACH",
                "recommended": True,
                "mode": "Family coach transfer from Plaça Espanya",
                "departure": "08:15",
                "return": "17:30",
                "journey_minutes": 70,
                "family_price_usd": 97,
                "why_recommended": "Direct, no changes, timed for the 18:00 cooking workshop.",
            },
            {
                "option_id": "DT-TRAIN",
                "recommended": False,
                "mode": "FGC train R5 + rack railway",
                "family_price_usd": 84,
                "why_not_recommended": "Two changes with children, adds 40 min connection each way.",
            },
        ],
        "recommendation": "DT-COACH — $97 for the family, round trip.",
        "subtotal_usd": 97,
        "category_subtotal_usd": TRANSPORT_SUBTOTAL,
        "category_subtotal_note": "Local transport category subtotal is $415 ($190 airport transfers + $128 transit passes + $97 Montserrat coach).",
    }, indent=2)
