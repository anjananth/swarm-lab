#!/usr/bin/env bash
# Import script for Use Case 03: Vacation Travel Planning Swarm (Parallel + Emergent)
# Prerequisites: `orchestrate` CLI installed and authenticated.

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "${SCRIPT_DIR}"

echo "=========================================================="
echo " 🏖️ Watson Orchestrate — Use Case 03: Vacation Planning Swarm"
echo "=========================================================="

echo ""
echo "── Step 1: Importing Tools ──"

echo "  [1/1] Vacation Planning Tools (vacation_tools.py)"
orchestrate tools import -k python -f tools/vacation_tools.py

echo ""
echo "✅ All tools imported successfully."

echo ""
echo "── Step 2: Importing Specialist Agents ──"

echo "  [1/4] flight_search_agent"
orchestrate agents import -f agents/flight_search_agent.yaml

echo "  [2/4] hotel_search_agent"
orchestrate agents import -f agents/hotel_search_agent.yaml

echo "  [3/4] activities_agent"
orchestrate agents import -f agents/activities_agent.yaml

echo "  [4/4] local_transport_agent (Emergent Roster Agent)"
orchestrate agents import -f agents/local_transport_agent.yaml

echo ""
echo "── Step 3: Importing Swarm Coordinator Agent ──"

echo "  [Coordinator] vacation_planning_coordinator"
orchestrate agents import -f agents/vacation_planning_coordinator.yaml

echo ""
echo "=========================================================="
echo "✅ Vacation Planning Swarm imported successfully!"
echo "Target Coordinator: vacation_planning_coordinator"
echo "=========================================================="
